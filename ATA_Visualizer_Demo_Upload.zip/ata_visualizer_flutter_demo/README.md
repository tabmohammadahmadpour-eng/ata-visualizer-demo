# ATA Visualizer Demo

Offline Android demo source for ATA Visualizer.

Demo mode uses local test OTP `12345` and does not require the production server or real SMS service.
The production wall-segmentation AI model is not bundled; manual/local fallback remains available.
