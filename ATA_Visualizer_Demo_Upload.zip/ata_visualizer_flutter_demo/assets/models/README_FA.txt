ATA Visualizer v0.7

این پوشه قرارداد runtime مدل را دارد، اما عمداً وزن production را همراه سورس قرار نمی‌دهد.

فایل لازم برای فعال‌شدن AI واقعی:
  wall_segmenter.tflite

قرارداد مدل در model_manifest.json تعریف شده است.
مدل پیشنهادی production: binary wall segmentation با خروجی probability mask.

برای آموزش وزن متعلق به پروژه، پوشه training/ را ببینید.
تا قبل از وجود فایل مدل، اپ به fallback نسخه محلی برمی‌گردد.
