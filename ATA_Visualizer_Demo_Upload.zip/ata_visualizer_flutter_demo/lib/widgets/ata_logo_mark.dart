import 'package:flutter/material.dart';
import '../core/theme/ata_theme.dart';

class AtaLogoMark extends StatelessWidget {
  final double size;
  const AtaLogoMark({super.key, this.size = 86});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AtaColors.border),
            ),
          ),
          Text('ATA', style: TextStyle(fontWeight: FontWeight.w900, fontSize: size * .29, color: AtaColors.black)),
          Positioned(top: 3, child: Row(children: [
            _dot(AtaColors.red), const SizedBox(width: 3), _dot(AtaColors.yellow), const SizedBox(width: 3), _dot(AtaColors.blue),
          ])),
          Positioned(bottom: 2, left: size * .08, right: size * .08, child: Row(children: [
            Expanded(child: Container(height: 2, color: AtaColors.blue)),
            Expanded(child: Container(height: 2, color: AtaColors.red)),
            Expanded(child: Container(height: 2, color: AtaColors.yellow)),
          ])),
        ],
      ),
    );
  }

  Widget _dot(Color c) => Container(width: 7, height: 7, decoration: BoxDecoration(color: c, shape: BoxShape.circle));
}
