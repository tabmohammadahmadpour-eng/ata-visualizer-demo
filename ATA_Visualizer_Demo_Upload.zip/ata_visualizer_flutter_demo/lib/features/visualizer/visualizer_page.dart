import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/models/color_family.dart';
import '../../core/models/wall_mask.dart';
import '../../core/models/wall_polygon.dart';
import '../../core/services/image_metadata_service.dart';
import '../../core/services/behavioral_analytics_service.dart';
import '../../core/services/project_local_store.dart';
import '../../core/services/user_library_api_service.dart';
import '../../core/theme/ata_theme.dart';
import 'widgets/wall_mask_painter.dart';
import 'widgets/wall_polygon_painter.dart';

class VisualizerPage extends StatefulWidget {
  final AtaPaintColor color;
  final String? colorFamily;
  final String? imagePath;
  final WallMask? wallMask;
  final WallPolygon? wallPolygon;

  const VisualizerPage({
    super.key,
    required this.color,
    this.colorFamily,
    this.imagePath,
    this.wallMask,
    this.wallPolygon,
  });

  @override
  State<VisualizerPage> createState() => _VisualizerPageState();
}

class _VisualizerPageState extends State<VisualizerPage> {
  final _analytics = BehavioralAnalyticsService.instance;
  final _library = UserLibraryApiService();
  final _localProjects = ProjectLocalStore();
  bool before = false;
  bool favorite = false;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _loadFavoriteState();
  }

  Future<void> _loadFavoriteState() async {
    try {
      final items = await _library.listFavorites();
      if (mounted) setState(() => favorite = items.any((x) => x.ataCode == widget.color.code));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('پیش‌نمایش روی دیوار')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('قبل')),
                  ButtonSegment(value: false, label: Text('بعد')),
                ],
                selected: {before},
                onSelectionChanged: (v) => setState(() => before = v.first),
              ),
            ),
            Expanded(
              child: widget.imagePath != null && (widget.wallMask?.isValid == true || widget.wallPolygon?.isValid == true)
                  ? _realImagePreview()
                  : _demoRoom(before ? const Color(0xFFE9E6DF) : widget.color.color),
            ),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: AtaColors.border)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: widget.color.color,
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${widget.color.code} | ${widget.color.nameFa}',
                              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 3),
                            Text('RGB: ${widget.color.rgb}', style: const TextStyle(color: AtaColors.muted, fontSize: 12)),
                            Text('HEX: ${widget.color.hex}', style: const TextStyle(color: AtaColors.muted, fontSize: 12)),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: favorite ? 'حذف از علاقه‌مندی' : 'ذخیره رنگ',
                        onPressed: () async {
                          final next = !favorite;
                          setState(() => favorite = next);
                          try {
                            if (next) {
                              await _library.saveFavorite(widget.color, familyName: widget.colorFamily);
                              unawaited(_analytics.trackColorSaved(widget.color, familyName: widget.colorFamily));
                            } else {
                              await _library.deleteFavorite(widget.color.code);
                              unawaited(_analytics.trackColorUnsaved(widget.color, familyName: widget.colorFamily));
                            }
                          } catch (_) {
                            if (mounted) setState(() => favorite = !next);
                          }
                        },
                        icon: Icon(favorite ? Icons.favorite : Icons.favorite_border),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => setState(() => before = !before),
                          icon: const Icon(Icons.compare_arrows),
                          label: const Text('قبل / بعد'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: saving ? null : _saveProject,
                          icon: const Icon(Icons.bookmark_outline),
                          label: const Text('ذخیره پروژه'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveProject() async {
    final controller = TextEditingController(text: 'پروژه ${widget.color.nameFa}');
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ذخیره پروژه'),
        content: TextField(controller: controller, autofocus: true, maxLength: 120, decoration: const InputDecoration(labelText: 'نام پروژه')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('ذخیره')),
        ],
      ),
    );
    controller.dispose();
    if (title == null || title.isEmpty || !mounted) return;

    setState(() => saving = true);
    try {
      final project = await _library.createProject(
        title: title,
        color: widget.color,
        familyName: widget.colorFamily,
        hasImage: widget.imagePath != null,
        hasAiMask: widget.wallMask?.isValid == true,
      );
      await _localProjects.save(
        projectId: project.id,
        sourceImagePath: widget.imagePath,
        wallMask: widget.wallMask,
        wallPolygon: widget.wallPolygon,
      );
      unawaited(_analytics.trackProjectSaveRequested(
        widget.color,
        familyName: widget.colorFamily,
        hasImage: widget.imagePath != null,
        hasAiMask: widget.wallMask?.isValid == true,
      ));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پروژه ذخیره شد.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ذخیره پروژه انجام نشد: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Widget _realImagePreview() {
    final path = widget.imagePath!;
    final mask = widget.wallMask;
    final polygon = widget.wallPolygon;

    return FutureBuilder<Size>(
      future: ImageMetadataService.readPixelSize(path),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final imageSize = snapshot.data!;
        final ratio = imageSize.width / imageSize.height;

        return Center(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: AspectRatio(
              aspectRatio: ratio,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final displaySize = Size(constraints.maxWidth, constraints.maxHeight);
                  final points = polygon?.denormalize(displaySize) ?? const <Offset>[];

                  return ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(File(path), fit: BoxFit.fill),
                        if (!before && mask != null)
                          IgnorePointer(
                            child: CustomPaint(
                              painter: WallMaskPainter(
                                mask: mask,
                                color: widget.color.color,
                                previewColor: true,
                              ),
                            ),
                          )
                        else if (!before && polygon?.isValid == true)
                          ClipPath(
                            clipper: WallClipper(points),
                            child: ColorFiltered(
                              colorFilter: ColorFilter.mode(
                                widget.color.color,
                                BlendMode.color,
                              ),
                              child: Image.file(File(path), fit: BoxFit.fill),
                            ),
                          ),
                        if (!before && polygon?.isValid == true && mask == null)
                          IgnorePointer(
                            child: CustomPaint(
                              painter: WallPolygonPainter(
                                points: points,
                                accent: Colors.white.withValues(alpha: .62),
                                showHandles: false,
                              ),
                            ),
                          ),
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: .55),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Text(
                              before ? 'تصویر اصلی' : 'پیش‌نمایش رنگ',
                              style: const TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _demoRoom(Color wall) {
    return Container(
      color: wall,
      child: Stack(
        children: [
          Positioned(left: 0, top: 0, bottom: 0, width: 70, child: Container(color: Colors.white.withValues(alpha: .82))),
          Positioned(left: 18, top: 50, width: 34, height: 150, child: Container(color: const Color(0xFFBFD8EF))),
          Positioned(left: 0, right: 0, bottom: 0, height: 95, child: Container(color: const Color(0xFFD8C2A4))),
          Positioned(left: 70, right: 70, bottom: 78, height: 130, child: Container(decoration: BoxDecoration(color: const Color(0xFFE5DED5), borderRadius: BorderRadius.circular(26)))),
          Positioned(left: 105, bottom: 145, width: 95, height: 38, child: Container(decoration: BoxDecoration(color: const Color(0xFFC3B3A6), borderRadius: BorderRadius.circular(14)))),
          Positioned(
            right: 45,
            bottom: 90,
            child: Column(
              children: [
                const Icon(Icons.local_florist, color: Color(0xFF4B784D), size: 62),
                Container(width: 52, height: 45, decoration: BoxDecoration(color: const Color(0xFF9A7357), borderRadius: BorderRadius.circular(12))),
              ],
            ),
          ),
          Positioned(
            top: 14,
            right: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.black.withValues(alpha: .5), borderRadius: BorderRadius.circular(20)),
              child: const Text('نمونه نمایشی', style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }
}
