import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/models/wall_detection_result.dart';
import '../../core/models/wall_mask.dart';
import '../../core/models/wall_polygon.dart';
import '../../core/services/image_metadata_service.dart';
import '../../core/services/smart_local_wall_detection_service.dart';
import '../../core/services/tflite_wall_segmentation_service.dart';
import '../../core/services/wall_detection_service.dart';
import '../../core/theme/ata_theme.dart';
import '../colors/color_picker_page.dart';
import 'widgets/wall_mask_painter.dart';
import 'widgets/wall_polygon_painter.dart';

enum _MaskEditMode { add, erase }

class WallSelectionPage extends StatefulWidget {
  final String imagePath;
  final WallDetectionService? detectionService;

  const WallSelectionPage({
    super.key,
    required this.imagePath,
    this.detectionService,
  });

  @override
  State<WallSelectionPage> createState() => _WallSelectionPageState();
}

class _WallSelectionPageState extends State<WallSelectionPage> {
  final List<Offset> _normalizedPoints = [];
  WallMask? _mask;
  late final Future<Size> _imageSizeFuture =
      ImageMetadataService.readPixelSize(widget.imagePath);
  late final WallDetectionService _detectionService = widget.detectionService ??
      TfliteWallSegmentationService(
        fallback: const SmartLocalWallDetectionService(),
      );

  bool _detecting = false;
  WallDetectionResult? _lastDetection;
  int? _draggingPointIndex;
  _MaskEditMode _maskEditMode = _MaskEditMode.add;
  double _brushRadius = .045;

  void _addPoint(Offset local, Size displaySize) {
    setState(() {
      _mask = null;
      _normalizedPoints.add(WallPolygon.normalize(local, displaySize));
      _lastDetection = null;
    });
  }

  void _editMask(Offset local, Size displaySize) {
    final mask = _mask;
    if (mask == null) return;
    final normalized = WallPolygon.normalize(local, displaySize);
    setState(() {
      _mask = mask.paintCircle(
        normalizedCenter: normalized,
        normalizedRadius: _brushRadius,
        include: _maskEditMode == _MaskEditMode.add,
      );
      _lastDetection = null;
    });
  }

  Future<void> _autoDetect() async {
    if (_detecting) return;
    setState(() => _detecting = true);
    try {
      final result = await _detectionService.detectWall(widget.imagePath);
      if (!mounted) return;
      if (result == null || !result.isValid) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'در این تصویر دیوار با اطمینان کافی پیدا نشد. می‌توانید محدوده را دستی مشخص کنید.',
            ),
          ),
        );
        return;
      }
      setState(() {
        _mask = result.mask?.copy();
        _normalizedPoints
          ..clear()
          ..addAll(result.polygon?.points ?? const <Offset>[]);
        _lastDetection = result;
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تشخیص خودکار انجام نشد. انتخاب دستی همچنان در دسترس است.'),
        ),
      );
    } finally {
      if (mounted) setState(() => _detecting = false);
    }
  }

  int? _nearestPointIndex(Offset local, Size displaySize) {
    if (_normalizedPoints.isEmpty) return null;
    final points = WallPolygon(_normalizedPoints).denormalize(displaySize);
    double bestDistance = 24;
    int? bestIndex;
    for (int i = 0; i < points.length; i++) {
      final distance = (points[i] - local).distance;
      if (distance < bestDistance) {
        bestDistance = distance;
        bestIndex = i;
      }
    }
    return bestIndex;
  }

  bool get _hasValidSelection =>
      _mask?.isValid == true || _normalizedPoints.length >= 3;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('انتخاب دیوار')),
        body: FutureBuilder<Size>(
          future: _imageSizeFuture,
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final pixelSize = snapshot.data!;
            final aspectRatio = pixelSize.width / pixelSize.height;

            return SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
                    child: Column(
                      children: [
                        Text(
                          _mask != null
                              ? 'قسمت آبی، ماسک دیوار است. با قلم و پاک‌کن آن را دقیق کنید تا پنجره، تلویزیون و وسایل رنگ نشوند.'
                              : 'ابتدا «تشخیص هوشمند» را امتحان کنید. اگر مدل در دسترس نباشد، پیشنهاد محلی اجرا می‌شود و انتخاب دستی هم همیشه فعال است.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: AtaColors.muted, height: 1.5),
                        ),
                        if (_lastDetection != null) ...[
                          const SizedBox(height: 7),
                          _DetectionBadge(result: _lastDetection!),
                        ],
                      ],
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        child: AspectRatio(
                          aspectRatio: aspectRatio,
                          child: LayoutBuilder(
                            builder: (context, constraints) {
                              final size = Size(constraints.maxWidth, constraints.maxHeight);
                              final points = WallPolygon(_normalizedPoints).denormalize(size);
                              return GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTapDown: (details) {
                                  if (_mask != null) {
                                    _editMask(details.localPosition, size);
                                  } else if (_nearestPointIndex(details.localPosition, size) == null) {
                                    _addPoint(details.localPosition, size);
                                  }
                                },
                                onPanStart: (details) {
                                  if (_mask != null) {
                                    _editMask(details.localPosition, size);
                                  } else {
                                    _draggingPointIndex =
                                        _nearestPointIndex(details.localPosition, size);
                                  }
                                },
                                onPanUpdate: (details) {
                                  if (_mask != null) {
                                    _editMask(details.localPosition, size);
                                    return;
                                  }
                                  final index = _draggingPointIndex;
                                  if (index == null || index >= _normalizedPoints.length) return;
                                  setState(() {
                                    _normalizedPoints[index] =
                                        WallPolygon.normalize(details.localPosition, size);
                                    _lastDetection = null;
                                  });
                                },
                                onPanEnd: (_) => _draggingPointIndex = null,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Image.file(File(widget.imagePath), fit: BoxFit.fill),
                                      if (_mask != null)
                                        IgnorePointer(
                                          child: CustomPaint(
                                            painter: WallMaskPainter(
                                              mask: _mask!,
                                              color: AtaColors.blue,
                                            ),
                                          ),
                                        )
                                      else
                                        IgnorePointer(
                                          child: CustomPaint(
                                            painter: WallPolygonPainter(
                                              points: points,
                                              accent: AtaColors.blue,
                                            ),
                                          ),
                                        ),
                                      if (_detecting)
                                        Container(
                                          color: Colors.black.withValues(alpha: .24),
                                          alignment: Alignment.center,
                                          child: const Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              CircularProgressIndicator(color: Colors.white),
                                              SizedBox(height: 12),
                                              Text(
                                                'در حال تشخیص دیوار…',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w800,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(top: BorderSide(color: AtaColors.border)),
                    ),
                    child: Column(
                      children: [
                        FilledButton.icon(
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(48),
                            backgroundColor: AtaColors.blue,
                          ),
                          onPressed: _detecting ? null : _autoDetect,
                          icon: const Icon(Icons.auto_awesome_outlined),
                          label: Text(
                            _detecting ? 'در حال تشخیص…' : 'تشخیص هوشمند دیوار',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        if (_mask != null) ...[
                          const SizedBox(height: 9),
                          Row(
                            children: [
                              Expanded(
                                child: SegmentedButton<_MaskEditMode>(
                                  segments: const [
                                    ButtonSegment(
                                      value: _MaskEditMode.add,
                                      icon: Icon(Icons.brush_outlined),
                                      label: Text('افزودن'),
                                    ),
                                    ButtonSegment(
                                      value: _MaskEditMode.erase,
                                      icon: Icon(Icons.auto_fix_off_outlined),
                                      label: Text('پاک‌کن'),
                                    ),
                                  ],
                                  selected: {_maskEditMode},
                                  onSelectionChanged: (v) =>
                                      setState(() => _maskEditMode = v.first),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              const Text('اندازه قلم', style: TextStyle(fontSize: 12)),
                              Expanded(
                                child: Slider(
                                  value: _brushRadius,
                                  min: .018,
                                  max: .10,
                                  onChanged: (v) => setState(() => _brushRadius = v),
                                ),
                              ),
                            ],
                          ),
                        ] else ...[
                          const SizedBox(height: 9),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _normalizedPoints.isEmpty
                                      ? null
                                      : () => setState(() {
                                            _normalizedPoints.removeLast();
                                            _lastDetection = null;
                                          }),
                                  icon: const Icon(Icons.undo),
                                  label: const Text('برگشت یک نقطه'),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _normalizedPoints.isEmpty
                                      ? null
                                      : () => setState(() {
                                            _normalizedPoints.clear();
                                            _lastDetection = null;
                                          }),
                                  icon: const Icon(Icons.delete_outline),
                                  label: const Text('پاک کردن'),
                                ),
                              ),
                            ],
                          ),
                        ],
                        const SizedBox(height: 9),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: !_hasValidSelection
                                    ? null
                                    : () => setState(() {
                                          _mask = null;
                                          _normalizedPoints.clear();
                                          _lastDetection = null;
                                        }),
                                icon: const Icon(Icons.restart_alt),
                                label: const Text('شروع دوباره'),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              flex: 2,
                              child: FilledButton.icon(
                                style: FilledButton.styleFrom(
                                  minimumSize: const Size.fromHeight(50),
                                  backgroundColor: AtaColors.black,
                                ),
                                onPressed: !_hasValidSelection
                                    ? null
                                    : () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => ColorPickerPage(
                                              imagePath: widget.imagePath,
                                              wallMask: _mask,
                                              wallPolygon: _mask == null
                                                  ? WallPolygon(List.unmodifiable(_normalizedPoints))
                                                  : null,
                                            ),
                                          ),
                                        );
                                      },
                                icon: const Icon(Icons.check_circle_outline),
                                label: const Text(
                                  'تأیید و انتخاب رنگ',
                                  style: TextStyle(fontWeight: FontWeight.w800),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _DetectionBadge extends StatelessWidget {
  final WallDetectionResult result;

  const _DetectionBadge({required this.result});

  @override
  Widget build(BuildContext context) {
    final isAi = result.method == WallDetectionMethod.aiModel;
    final confidence = result.confidence;
    final detail = confidence == null
        ? (isAi ? 'ماسک پیکسلی AI' : 'پیشنهاد خودکار')
        : 'اطمینان تقریبی ${(confidence * 100).round()}٪';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AtaColors.softGray,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AtaColors.border),
      ),
      child: Text(
        '${isAi ? 'تشخیص مدل' : 'تشخیص محلی'} • $detail • قابل اصلاح',
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}
