import 'package:flutter/material.dart';

class WallPolygonPainter extends CustomPainter {
  final List<Offset> points;
  final Color accent;
  final bool showHandles;

  const WallPolygonPainter({
    required this.points,
    required this.accent,
    this.showHandles = true,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) return;

    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final point in points.skip(1)) {
      path.lineTo(point.dx, point.dy);
    }
    if (points.length >= 3) path.close();

    if (points.length >= 3) {
      canvas.drawPath(
        path,
        Paint()
          ..color = accent.withValues(alpha: .18)
          ..style = PaintingStyle.fill,
      );
    }

    canvas.drawPath(
      path,
      Paint()
        ..color = accent
        ..strokeWidth = 3
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round,
    );

    if (!showHandles) return;
    final handlePaint = Paint()..color = Colors.white;
    final borderPaint = Paint()
      ..color = accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (final point in points) {
      canvas.drawCircle(point, 7, handlePaint);
      canvas.drawCircle(point, 7, borderPaint);
    }
  }

  @override
  bool shouldRepaint(covariant WallPolygonPainter oldDelegate) =>
      oldDelegate.points != points ||
      oldDelegate.accent != accent ||
      oldDelegate.showHandles != showHandles;
}

class WallClipper extends CustomClipper<Path> {
  final List<Offset> points;

  const WallClipper(this.points);

  @override
  Path getClip(Size size) {
    if (points.length < 3) return Path();
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final p in points.skip(1)) {
      path.lineTo(p.dx, p.dy);
    }
    return path..close();
  }

  @override
  bool shouldReclip(covariant WallClipper oldClipper) => oldClipper.points != points;
}
