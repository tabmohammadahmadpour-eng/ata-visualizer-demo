import 'package:flutter/material.dart';

import '../../../core/models/wall_mask.dart';

/// Efficiently paints a binary wall mask as horizontal runs.
///
/// In selection mode it shows a translucent ATA-blue overlay. In preview mode
/// it uses BlendMode.color so the wall's luminance/shadows remain visible.
class WallMaskPainter extends CustomPainter {
  final WallMask mask;
  final Color color;
  final bool previewColor;
  final double opacity;

  const WallMaskPainter({
    required this.mask,
    required this.color,
    this.previewColor = false,
    this.opacity = .28,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cellW = size.width / mask.width;
    final cellH = size.height / mask.height;
    final paint = Paint()
      ..color = color.withValues(alpha: previewColor ? .94 : opacity)
      ..style = PaintingStyle.fill
      ..blendMode = previewColor ? BlendMode.color : BlendMode.srcOver;

    for (int y = 0; y < mask.height; y++) {
      int x = 0;
      while (x < mask.width) {
        while (x < mask.width && !mask.containsCell(x, y)) {
          x++;
        }
        if (x >= mask.width) break;
        final start = x;
        while (x < mask.width && mask.containsCell(x, y)) {
          x++;
        }
        canvas.drawRect(
          Rect.fromLTWH(start * cellW, y * cellH, (x - start) * cellW + .5, cellH + .5),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant WallMaskPainter oldDelegate) =>
      oldDelegate.mask.data != mask.data ||
      oldDelegate.color != color ||
      oldDelegate.previewColor != previewColor ||
      oldDelegate.opacity != opacity;
}
