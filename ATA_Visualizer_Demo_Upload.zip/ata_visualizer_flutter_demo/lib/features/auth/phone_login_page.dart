import 'package:flutter/material.dart';

import '../../core/config/app_config.dart';
import '../../core/services/auth_api_service.dart';
import '../../core/theme/ata_theme.dart';
import '../../widgets/ata_logo_mark.dart';
import 'otp_page.dart';

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});

  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final controller = TextEditingController();
  final _api = AuthApiService();
  bool smsConsent = false;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _requestOtp() async {
    if (_busy) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final result = await _api.requestOtp(phone: controller.text, smsConsent: smsConsent);
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => OtpPage(
            phone: controller.text,
            debugCode: result.debugCode,
            expiresInSeconds: result.expiresInSeconds,
          ),
        ),
      );
    } on AuthApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              const SizedBox(height: 36),
              const Center(child: AtaLogoMark(size: 112)),
              const SizedBox(height: 32),
              const Text('ورود یا ثبت‌نام', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              const Text('برای ادامه، شماره موبایل خود را وارد کنید.', textAlign: TextAlign.center, style: TextStyle(color: AtaColors.muted)),
              const SizedBox(height: 24),
              if (AppConfig.demoMode) ...[
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AtaColors.yellow.withValues(alpha: .18),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Text(
                    'نسخه آزمایشی آتا: پیامک واقعی ارسال نمی‌شود. کد ورود دمو 12345 است.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 18),
              ],
              const Text('شماره موبایل', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              TextField(
                controller: controller,
                keyboardType: TextInputType.phone,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(hintText: '0912 345 6789'),
                onSubmitted: (_) => _requestOtp(),
              ),
              const SizedBox(height: 16),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: smsConsent,
                onChanged: (v) => setState(() => smsConsent = v ?? false),
                title: const Text('مایلم پیشنهادها و رنگ‌های جدید آتا را از طریق پیامک دریافت کنم.', style: TextStyle(fontSize: 14)),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AtaColors.red)),
              ],
              const SizedBox(height: 16),
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56), backgroundColor: AtaColors.blue),
                onPressed: _busy ? null : _requestOtp,
                child: _busy
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('ارسال کد تأیید', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 18),
              const Text('رضایت دریافت پیامک تبلیغاتی اختیاری است و برای ورود به اپ اجباری نیست.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AtaColors.muted)),
            ],
          ),
        ),
      ),
    );
  }
}
