import 'package:flutter/material.dart';

import '../../core/services/auth_api_service.dart';
import '../../core/services/secure_session_store.dart';
import '../../core/theme/ata_theme.dart';
import '../../widgets/ata_logo_mark.dart';
import '../home/home_page.dart';

class OtpPage extends StatefulWidget {
  final String phone;
  final String? debugCode;
  final int expiresInSeconds;

  const OtpPage({
    super.key,
    required this.phone,
    this.debugCode,
    required this.expiresInSeconds,
  });

  @override
  State<OtpPage> createState() => _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {
  late final TextEditingController controller;
  final _api = AuthApiService();
  final _store = const SecureSessionStore();
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.debugCode ?? '');
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_busy || controller.text.length != 5) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final session = await _api.verifyOtp(phone: widget.phone, code: controller.text);
      await _store.saveToken(session.accessToken);
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomePage()),
        (_) => false,
      );
    } on AuthApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(),
        body: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Center(child: AtaLogoMark()),
            const SizedBox(height: 28),
            const Text('تأیید شماره موبایل', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text('کد تأیید ارسال شده به ${widget.phone}', textAlign: TextAlign.center, style: const TextStyle(color: AtaColors.muted)),
            const SizedBox(height: 28),
            TextField(
              controller: controller,
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number,
              maxLength: 5,
              style: const TextStyle(fontSize: 26, letterSpacing: 12, fontWeight: FontWeight.w700),
              decoration: const InputDecoration(counterText: '', hintText: '•••••'),
              onSubmitted: (_) => _verify(),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AtaColors.red)),
            ],
            const SizedBox(height: 16),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56), backgroundColor: AtaColors.blue),
              onPressed: _busy ? null : _verify,
              child: _busy
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('تأیید و ورود'),
            ),
            if (widget.debugCode != null) ...[
              const SizedBox(height: 16),
              Text('حالت توسعه: کد آزمایشی ${widget.debugCode}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AtaColors.muted)),
            ],
          ],
        ),
      ),
    );
  }
}
