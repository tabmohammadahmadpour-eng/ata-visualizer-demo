import 'package:flutter/material.dart';

import '../../core/services/auth_api_service.dart';
import '../../core/services/secure_session_store.dart';
import '../home/home_page.dart';
import 'phone_login_page.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final _store = const SecureSessionStore();
  final _api = AuthApiService();
  Widget? _next;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    final token = await _store.readToken();
    if (token == null || token.isEmpty) {
      if (mounted) setState(() => _next = const PhoneLoginPage());
      return;
    }

    try {
      await _api.me(token);
      if (mounted) setState(() => _next = const HomePage());
    } catch (_) {
      await _store.clear();
      if (mounted) setState(() => _next = const PhoneLoginPage());
    }
  }

  @override
  Widget build(BuildContext context) {
    return _next ?? const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}
