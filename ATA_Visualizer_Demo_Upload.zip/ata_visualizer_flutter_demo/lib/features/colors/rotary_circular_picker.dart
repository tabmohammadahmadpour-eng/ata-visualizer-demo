import 'dart:math' as math;
import 'package:flutter/material.dart';

/// A reusable rotary circular picker.
///
/// Only a limited number of neighboring items are painted at once, so this
/// control remains practical even when an ATA color family later contains
/// dozens or hundreds of colors loaded from the server.
class RotaryCircularPicker<T> extends StatefulWidget {
  final List<T> items;
  final int selectedIndex;
  final ValueChanged<int> onChanged;
  final Widget Function(BuildContext context, T item, bool selected) itemBuilder;
  final Widget Function(BuildContext context, T selectedItem) centerBuilder;
  final int maxVisibleItems;
  final double diameter;
  final VoidCallback? onStepFeedback;
  final VoidCallback? onSettledFeedback;

  const RotaryCircularPicker({
    super.key,
    required this.items,
    required this.selectedIndex,
    required this.onChanged,
    required this.itemBuilder,
    required this.centerBuilder,
    this.maxVisibleItems = 9,
    this.diameter = 350,
    this.onStepFeedback,
    this.onSettledFeedback,
  });

  @override
  State<RotaryCircularPicker<T>> createState() => _RotaryCircularPickerState<T>();
}

class _RotaryCircularPickerState<T> extends State<RotaryCircularPicker<T>> {
  double _rotation = 0;
  double? _lastAngle;
  int _lastFeedbackStep = 0;

  @override
  Widget build(BuildContext context) {
    if (widget.items.isEmpty) return const SizedBox.shrink();

    return LayoutBuilder(
      builder: (context, constraints) {
        final diameter = math.min(widget.diameter, constraints.maxWidth);
        final visible = math.min(widget.items.length, widget.maxVisibleItems);
        final slotCount = visible.isEven && visible > 1 ? visible - 1 : visible;
        final step = 2 * math.pi / slotCount;
        final radius = diameter * .39;
        final half = slotCount ~/ 2;

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onPanStart: (details) {
            _lastAngle = _angle(details.localPosition, Size.square(diameter));
            _lastFeedbackStep = 0;
          },
          onPanUpdate: (details) {
            final current = _angle(details.localPosition, Size.square(diameter));
            final previous = _lastAngle;
            if (previous != null) {
              var delta = current - previous;
              if (delta > math.pi) delta -= 2 * math.pi;
              if (delta < -math.pi) delta += 2 * math.pi;
              setState(() => _rotation += delta);
              final crossedStep = (_rotation / step).round();
              if (crossedStep != _lastFeedbackStep) {
                _lastFeedbackStep = crossedStep;
                widget.onStepFeedback?.call();
              }
            }
            _lastAngle = current;
          },
          onPanEnd: (_) {
            final movedSteps = (_rotation / step).round();
            final newIndex = _wrap(widget.selectedIndex - movedSteps, widget.items.length);
            setState(() {
              _rotation = 0;
              _lastAngle = null;
            });
            if (newIndex != widget.selectedIndex) {
              widget.onSettledFeedback?.call();
              widget.onChanged(newIndex);
            }
          },
          child: SizedBox(
            width: diameter,
            height: diameter,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: diameter,
                  height: diameter,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFFE6E7EA), width: 2),
                  ),
                ),
                for (int slot = -half; slot <= half; slot++)
                  _buildSlot(
                    context: context,
                    slot: slot,
                    step: step,
                    radius: radius,
                    selectedIndex: widget.selectedIndex,
                  ),
                Container(
                  width: diameter * .34,
                  height: diameter * .34,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFFE6E7EA)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: .06),
                        blurRadius: 18,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: widget.centerBuilder(context, widget.items[widget.selectedIndex]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSlot({
    required BuildContext context,
    required int slot,
    required double step,
    required double radius,
    required int selectedIndex,
  }) {
    final itemIndex = _wrap(selectedIndex + slot, widget.items.length);
    final angle = -math.pi / 2 + slot * step + _rotation;
    final x = math.cos(angle) * radius;
    final y = math.sin(angle) * radius;
    final selected = slot == 0;

    return Transform.translate(
      offset: Offset(x, y),
      child: AnimatedScale(
        duration: const Duration(milliseconds: 160),
        scale: selected ? 1.14 : 1,
        child: widget.itemBuilder(context, widget.items[itemIndex], selected),
      ),
    );
  }

  int _wrap(int value, int length) => ((value % length) + length) % length;

  double _angle(Offset point, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final vector = point - center;
    return math.atan2(vector.dy, vector.dx);
  }
}
