import 'dart:async';

import 'package:flutter/material.dart';
import '../../core/data/ata_palette_repository.dart';
import '../../core/models/color_family.dart';
import '../../core/theme/ata_theme.dart';
import '../../core/services/behavioral_analytics_service.dart';
import '../../core/services/rotary_feedback_service.dart';
import '../../core/models/wall_mask.dart';
import '../../core/models/wall_polygon.dart';
import '../visualizer/visualizer_page.dart';
import 'rotary_circular_picker.dart';

class ColorPickerPage extends StatefulWidget {
  final String? imagePath;
  final WallMask? wallMask;
  final WallPolygon? wallPolygon;

  const ColorPickerPage({super.key, this.imagePath, this.wallMask, this.wallPolygon});

  @override
  State<ColorPickerPage> createState() => _ColorPickerPageState();
}

class _ColorPickerPageState extends State<ColorPickerPage> {
  final _repository = const AtaPaletteRepository();
  final _analytics = BehavioralAnalyticsService.instance;
  final _rotaryFeedback = RotaryFeedbackService.instance;
  bool _initialViewTracked = false;
  late final Future<List<ColorFamily>> _familiesFuture = _repository.loadFamilies();

  int familyIndex = 0;
  int colorIndex = 0;

  @override
  void initState() {
    super.initState();
    unawaited(_rotaryFeedback.init());
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('انتخاب رنگ'),
          actions: [
            IconButton(
              tooltip: 'صدای حلقه رنگ',
              onPressed: () => _showFeedbackSettings(context),
              icon: const Icon(Icons.tune_rounded),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 12),
              child: Icon(Icons.search),
            ),
          ],
        ),
        body: FutureBuilder<List<ColorFamily>>(
          future: _familiesFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('کالیته رنگ در دسترس نیست.'));
            }

            final families = snapshot.data!;
            if (familyIndex >= families.length) familyIndex = 0;
            final family = families[familyIndex];
            if (colorIndex >= family.colors.length) colorIndex = 0;
            final selected = family.colors[colorIndex];

            if (!_initialViewTracked) {
              _initialViewTracked = true;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _analytics.trackColorViewed(selected, familyName: family.name);
              });
            }

            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 32),
              children: [
                const Text(
                  'حلقه را با انگشت بچرخانید و طیف موردنظر را انتخاب کنید.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AtaColors.muted),
                ),
                const SizedBox(height: 12),
                Center(
                  child: RotaryCircularPicker<ColorFamily>(
                    items: families,
                    selectedIndex: familyIndex,
                    onStepFeedback: () => unawaited(_rotaryFeedback.tick()),
                    onSettledFeedback: () => unawaited(_rotaryFeedback.settle()),
                    onChanged: (index) {
                      final nextFamily = families[index];
                      setState(() {
                        familyIndex = index;
                        colorIndex = 0;
                      });
                      if (nextFamily.colors.isNotEmpty) {
                        unawaited(_analytics.trackColorViewed(
                          nextFamily.colors.first,
                          familyName: nextFamily.name,
                        ));
                      }
                    },
                    maxVisibleItems: 9,
                    diameter: 330,
                    centerBuilder: (_, item) => Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item.icon, color: item.accent, size: 28),
                        const SizedBox(height: 7),
                        Text(
                          item.name,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                        ),
                      ],
                    ),
                    itemBuilder: (_, item, active) => Container(
                      width: active ? 82 : 66,
                      height: active ? 82 : 66,
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: item.accent,
                        border: Border.all(color: Colors.white, width: active ? 5 : 3),
                        boxShadow: active
                            ? [BoxShadow(color: item.accent.withValues(alpha: .25), blurRadius: 14)]
                            : null,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        item.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: active ? 10 : 8.5,
                          fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                          color: _contrast(item.accent),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'رنگ‌های طیف ${family.name}  •  ${family.colors.length} رنگ',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                const Text(
                  'برای دیدن رنگ‌های بیشتر، حلقه را با انگشت بچرخانید.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AtaColors.muted, fontSize: 12),
                ),
                const SizedBox(height: 10),
                Center(
                  child: RotaryCircularPicker<AtaPaintColor>(
                    items: family.colors,
                    selectedIndex: colorIndex,
                    onStepFeedback: () => unawaited(_rotaryFeedback.tick()),
                    onSettledFeedback: () => unawaited(_rotaryFeedback.settle()),
                    onChanged: (index) {
                      setState(() => colorIndex = index);
                      unawaited(_analytics.trackColorViewed(
                        family.colors[index],
                        familyName: family.name,
                      ));
                    },
                    maxVisibleItems: 9,
                    diameter: 290,
                    centerBuilder: (_, item) => Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(item.code, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
                        const SizedBox(height: 5),
                        Text(item.nameFa, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                      ],
                    ),
                    itemBuilder: (_, item, active) => Container(
                      width: active ? 62 : 48,
                      height: active ? 62 : 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: item.color,
                        border: Border.all(
                          color: active ? AtaColors.blue : Colors.white,
                          width: active ? 4 : 2,
                        ),
                        boxShadow: active
                            ? [BoxShadow(color: Colors.black.withValues(alpha: .12), blurRadius: 12)]
                            : null,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                _SelectedColorCard(color: selected),
                const SizedBox(height: 16),
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: AtaColors.blue,
                    minimumSize: const Size.fromHeight(58),
                  ),
                  onPressed: () {
                    unawaited(_analytics.trackColorApplied(
                      selected,
                      familyName: family.name,
                    ));
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => VisualizerPage(
                          color: selected,
                          colorFamily: family.name,
                          imagePath: widget.imagePath,
                          wallMask: widget.wallMask,
                          wallPolygon: widget.wallPolygon,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.format_paint_outlined),
                  label: const Text(
                    'اعمال رنگ روی دیوار',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> _showFeedbackSettings(BuildContext context) async {
    await _rotaryFeedback.init();
    if (!context.mounted) return;

    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
            child: AnimatedBuilder(
              animation: _rotaryFeedback,
              builder: (context, _) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'حس حلقه انتخاب رنگ',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'هنگام عبور از هر رنگ یک پاپ نرم پخش می‌شود و گوشی بازخورد ظریفی می‌دهد.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AtaColors.muted, fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    secondary: const Icon(Icons.volume_up_rounded),
                    title: const Text('صدای قرقره / حباب'),
                    subtitle: const Text('صدای کوتاه هنگام عبور و قفل‌شدن روی رنگ'),
                    value: _rotaryFeedback.soundEnabled,
                    onChanged: (value) => unawaited(_rotaryFeedback.setSoundEnabled(value)),
                  ),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    secondary: const Icon(Icons.vibration_rounded),
                    title: const Text('بازخورد لرزشی'),
                    subtitle: const Text('لرزش بسیار ظریف هنگام انتخاب'),
                    value: _rotaryFeedback.hapticsEnabled,
                    onChanged: (value) => unawaited(_rotaryFeedback.setHapticsEnabled(value)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  static Color _contrast(Color color) =>
      color.computeLuminance() > .58 ? Colors.black87 : Colors.white;
}

class _SelectedColorCard extends StatelessWidget {
  final AtaPaintColor color;

  const _SelectedColorCard({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: AtaColors.border),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: color.color,
              borderRadius: BorderRadius.circular(18),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${color.code} | ${color.nameFa}',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 6),
                Text('RGB: ${color.rgb}', style: const TextStyle(color: AtaColors.muted)),
                Text('HEX: ${color.hex}', style: const TextStyle(color: AtaColors.muted)),
                if (color.accuracy == ColorAccuracy.provisional)
                  const Padding(
                    padding: EdgeInsets.only(top: 5),
                    child: Text(
                      'نمایش دیجیتال اولیه',
                      style: TextStyle(color: AtaColors.muted, fontSize: 11),
                    ),
                  ),
              ],
            ),
          ),
          const Icon(Icons.favorite_border),
        ],
      ),
    );
  }
}
