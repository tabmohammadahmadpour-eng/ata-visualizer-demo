import 'package:flutter/material.dart';

import '../../core/models/auth_session.dart';
import '../../core/services/auth_api_service.dart';
import '../../core/services/project_local_store.dart';
import '../../core/services/rotary_feedback_service.dart';
import '../../core/services/secure_session_store.dart';
import '../../core/services/user_library_api_service.dart';
import '../../core/theme/ata_theme.dart';
import '../../widgets/ata_logo_mark.dart';
import '../auth/phone_login_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _auth = AuthApiService();
  final _session = const SecureSessionStore();
  final _library = UserLibraryApiService();
  final _localProjects = ProjectLocalStore();
  final _feedback = RotaryFeedbackService.instance;

  AuthUser? _user;
  bool _loading = true;
  bool _savingConsent = false;
  bool _privacyBusy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _feedback.init();
    _feedback.addListener(_onFeedbackChanged);
    _load();
  }

  @override
  void dispose() {
    _feedback.removeListener(_onFeedbackChanged);
    super.dispose();
  }

  void _onFeedbackChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final token = await _session.readToken();
      if (token == null || token.isEmpty) throw const AuthApiException('نشست کاربر پیدا نشد.');
      final user = await _auth.me(token);
      if (mounted) setState(() => _user = user);
    } on AuthApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _updateConsent({bool? sms, bool? push}) async {
    if (_savingConsent) return;
    final current = _user;
    if (current == null) return;
    setState(() => _savingConsent = true);
    try {
      final token = await _session.readToken();
      if (token == null) return;
      final updated = await _auth.updatePreferences(
        accessToken: token,
        smsConsent: sms,
        pushConsent: push,
      );
      if (mounted) setState(() => _user = updated);
    } on AuthApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _savingConsent = false);
    }
  }

  Future<void> _clearPrivateLocalData() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('پاک‌سازی تصاویر خصوصی؟'),
        content: const Text(
          'عکس اتاق، ماسک تشخیص دیوار و داده محلی پروژه‌ها از همین گوشی پاک می‌شود. '
          'نام پروژه‌ها و رنگ‌های ذخیره‌شده در حساب شما باقی می‌ماند.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('پاک‌سازی')),
        ],
      ),
    );
    if (ok != true || _privacyBusy) return;
    setState(() => _privacyBusy = true);
    try {
      final projects = await _library.listProjects();
      for (final project in projects) {
        await _localProjects.delete(project.id);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('داده‌های خصوصی محلی این گوشی پاک شد.')),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('پاک‌سازی کامل انجام نشد. دوباره تلاش کنید.')),
      );
    } finally {
      if (mounted) setState(() => _privacyBusy = false);
    }
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('خروج از حساب؟'),
        content: const Text('پروژه‌های حساب شما حذف نمی‌شوند. تصاویر خصوصی محلی نیز روی این گوشی باقی می‌مانند مگر جداگانه پاک‌شان کنید.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('خروج')),
        ],
      ),
    );
    if (ok != true) return;

    final token = await _session.readToken();
    if (token != null) {
      try {
        await _auth.logout(token);
      } catch (_) {
        // Local logout must still work when the backend is temporarily unreachable.
      }
    }
    await _session.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const PhoneLoginPage()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('پروفایل و تنظیمات')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 10, 18, 28),
                  children: [
                    const Center(child: AtaLogoMark(size: 76)),
                    const SizedBox(height: 16),
                    _accountCard(),
                    if (_error != null) ...[
                      const SizedBox(height: 10),
                      Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AtaColors.red)),
                    ],
                    const SizedBox(height: 22),
                    const _SectionTitle('ارتباط با آتا'),
                    _settingsCard(children: [
                      SwitchListTile(
                        value: _user?.smsConsent ?? false,
                        onChanged: _savingConsent ? null : (v) => _updateConsent(sms: v),
                        title: const Text('دریافت پیامک‌های آتا'),
                        subtitle: const Text('رنگ‌های جدید، پیشنهادها و کمپین‌های آتا'),
                        secondary: const Icon(Icons.sms_outlined),
                      ),
                      const Divider(height: 1),
                      SwitchListTile(
                        value: _user?.pushConsent ?? false,
                        onChanged: _savingConsent ? null : (v) => _updateConsent(push: v),
                        title: const Text('دریافت اعلان‌های آتا'),
                        subtitle: const Text('رضایت دریافت Push در حساب ذخیره می‌شود'),
                        secondary: const Icon(Icons.notifications_none),
                      ),
                    ]),
                    const SizedBox(height: 22),
                    const _SectionTitle('حس انتخاب رنگ'),
                    _settingsCard(children: [
                      SwitchListTile(
                        value: _feedback.soundEnabled,
                        onChanged: (v) => _feedback.setSoundEnabled(v),
                        title: const Text('صدای حلقه رنگ'),
                        subtitle: const Text('پاپ/کلیک نرم هنگام عبور از رنگ‌ها'),
                        secondary: const Icon(Icons.volume_up_outlined),
                      ),
                      const Divider(height: 1),
                      SwitchListTile(
                        value: _feedback.hapticsEnabled,
                        onChanged: (v) => _feedback.setHapticsEnabled(v),
                        title: const Text('لرزش ظریف حلقه'),
                        subtitle: const Text('بازخورد لمسی هنگام انتخاب و قفل شدن رنگ'),
                        secondary: const Icon(Icons.vibration),
                      ),
                    ]),
                    const SizedBox(height: 22),
                    const _SectionTitle('حریم خصوصی'),
                    _settingsCard(children: [
                      const ListTile(
                        leading: Icon(Icons.phonelink_lock_outlined),
                        title: Text('عکس‌های خانه فقط روی دستگاه'),
                        subtitle: Text('در نسخه فعلی عکس اتاق و ماسک دیوار به سرور ATA آپلود نمی‌شود.'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        enabled: !_privacyBusy,
                        leading: const Icon(Icons.cleaning_services_outlined),
                        title: const Text('پاک‌سازی تصاویر خصوصی این گوشی'),
                        subtitle: const Text('پروژه و رنگ در حساب می‌ماند؛ فقط فایل‌های محلی حذف می‌شوند.'),
                        trailing: _privacyBusy
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.chevron_left),
                        onTap: _privacyBusy ? null : _clearPrivateLocalData,
                      ),
                    ]),
                    const SizedBox(height: 24),
                    OutlinedButton.icon(
                      onPressed: _logout,
                      icon: const Icon(Icons.logout),
                      label: const Text('خروج از حساب'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AtaColors.red,
                        minimumSize: const Size.fromHeight(54),
                        side: const BorderSide(color: AtaColors.red),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'ATA Visualizer DEMO v0.15',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AtaColors.muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _accountCard() {
    final user = _user;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AtaColors.blue,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: const Icon(Icons.person_outline, color: AtaColors.blue, size: 30),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('حساب ATA', style: TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 3),
                Text(
                  user?.phone ?? 'شماره نامشخص',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 19),
                ),
                if (user?.phoneE164.isNotEmpty == true)
                  Text(
                    user!.phoneE164,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: _load,
            tooltip: 'به‌روزرسانی',
            icon: const Icon(Icons.refresh, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _settingsCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AtaColors.border),
        borderRadius: BorderRadius.circular(22),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 4, bottom: 9),
      child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
    );
  }
}
