import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/data/ata_palette_repository.dart';
import '../../core/models/saved_project.dart';
import '../../core/services/project_local_store.dart';
import '../../core/services/user_library_api_service.dart';
import '../../core/theme/ata_theme.dart';
import '../visualizer/visualizer_page.dart';

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});

  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  final _api = UserLibraryApiService();
  final _local = ProjectLocalStore();
  final _palette = const AtaPaletteRepository();
  late Future<List<SavedProject>> _future = _api.listProjects();

  void _reload() => setState(() => _future = _api.listProjects());

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('پروژه‌های من')),
        body: RefreshIndicator(
          onRefresh: () async => _reload(),
          child: FutureBuilder<List<SavedProject>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
              if (snapshot.hasError) return ListView(children: const [SizedBox(height: 180), Center(child: Text('دریافت پروژه‌ها انجام نشد.'))]);
              final projects = snapshot.data ?? const [];
              if (projects.isEmpty) return ListView(children: const [SizedBox(height: 180), Icon(Icons.folder_open, size: 52, color: AtaColors.muted), SizedBox(height: 12), Center(child: Text('هنوز پروژه‌ای ذخیره نکرده‌اید.'))]);
              return ListView.separated(
                padding: const EdgeInsets.all(18),
                itemCount: projects.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (_, i) => _ProjectTile(
                  project: projects[i],
                  localStore: _local,
                  onOpen: () => _open(projects[i]),
                  onRename: () => _rename(projects[i]),
                  onDelete: () => _delete(projects[i]),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _open(SavedProject project) async {
    final color = await _palette.findByCode(project.ataCode);
    if (!mounted) return;
    if (color == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('این رنگ در کالیته فعلی پیدا نشد.')));
      return;
    }
    final local = await _local.read(project.id);
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VisualizerPage(
          color: color,
          colorFamily: project.familyName,
          imagePath: local.hasImage ? local.imagePath : null,
          wallMask: local.wallMask,
          wallPolygon: local.wallPolygon,
        ),
      ),
    );
  }

  Future<void> _rename(SavedProject project) async {
    final controller = TextEditingController(text: project.title);
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('نام پروژه'),
        content: TextField(controller: controller, autofocus: true, maxLength: 120),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('ذخیره')),
        ],
      ),
    );
    controller.dispose();
    if (title == null || title.isEmpty) return;
    await _api.renameProject(project.id, title);
    if (mounted) _reload();
  }

  Future<void> _delete(SavedProject project) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف پروژه؟'),
        content: const Text('اطلاعات پروژه و نسخه محلی عکس از این گوشی حذف می‌شود.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    await _api.deleteProject(project.id);
    await _local.delete(project.id);
    if (mounted) _reload();
  }
}

class _ProjectTile extends StatelessWidget {
  final SavedProject project;
  final ProjectLocalStore localStore;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;

  const _ProjectTile({required this.project, required this.localStore, required this.onOpen, required this.onRename, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<LocalProjectData>(
      future: localStore.read(project.id),
      builder: (context, snapshot) {
        final local = snapshot.data;
        final hasPhoto = local?.hasImage == true;
        return InkWell(
          onTap: onOpen,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(border: Border.all(color: AtaColors.border), borderRadius: BorderRadius.circular(20)),
            child: Row(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: SizedBox(
                  width: 88,
                  height: 76,
                  child: hasPhoto
                      ? Image.file(File(local!.imagePath!), fit: BoxFit.cover)
                      : ColoredBox(color: _hex(project.hex), child: const Icon(Icons.format_paint_outlined, color: Colors.white)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(project.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('${project.ataCode} | ${project.nameFa}', style: const TextStyle(color: AtaColors.blue, fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(
                  hasPhoto ? 'عکس خصوصی روی همین دستگاه ذخیره است' : (project.hasImage ? 'اطلاعات پروژه همگام است؛ عکس روی این دستگاه نیست' : 'پروژه بدون عکس'),
                  style: const TextStyle(color: AtaColors.muted, fontSize: 11),
                ),
              ])),
              PopupMenuButton<String>(
                onSelected: (v) { if (v == 'rename') onRename(); if (v == 'delete') onDelete(); },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'rename', child: Text('تغییر نام')),
                  PopupMenuItem(value: 'delete', child: Text('حذف')),
                ],
              ),
            ]),
          ),
        );
      },
    );
  }

  static Color _hex(String? value) {
    if (value == null) return const Color(0xFFB9B9B9);
    try { return Color(int.parse('FF${value.replaceFirst('#', '')}', radix: 16)); } catch (_) { return const Color(0xFFB9B9B9); }
  }
}
