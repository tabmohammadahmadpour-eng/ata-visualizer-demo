import 'package:flutter/material.dart';

import '../../core/models/saved_project.dart';
import '../../core/services/user_library_api_service.dart';
import '../../core/theme/ata_theme.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  final _api = UserLibraryApiService();
  late Future<List<FavoriteColorRecord>> _future = _api.listFavorites();

  Future<void> _refresh() async => setState(() => _future = _api.listFavorites());

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('رنگ‌های مورد علاقه')),
        body: RefreshIndicator(
          onRefresh: _refresh,
          child: FutureBuilder<List<FavoriteColorRecord>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return ListView(children: const [SizedBox(height: 180), Center(child: Text('دریافت علاقه‌مندی‌ها انجام نشد.'))]);
              }
              final items = snapshot.data ?? const [];
              if (items.isEmpty) {
                return ListView(children: const [SizedBox(height: 180), Icon(Icons.favorite_border, size: 48, color: AtaColors.muted), SizedBox(height: 12), Center(child: Text('هنوز رنگی ذخیره نکرده‌اید.'))]);
              }
              return ListView.separated(
                padding: const EdgeInsets.all(18),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final item = items[i];
                  return Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(border: Border.all(color: AtaColors.border), borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      children: [
                        Container(width: 58, height: 58, decoration: BoxDecoration(color: _hex(item.hex), borderRadius: BorderRadius.circular(14))),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${item.ataCode} | ${item.nameFa}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          if (item.rgb != null) Text('RGB: ${item.rgb}', style: const TextStyle(color: AtaColors.muted, fontSize: 12)),
                          if (item.hex != null) Text('HEX: ${item.hex}', style: const TextStyle(color: AtaColors.muted, fontSize: 12)),
                        ])),
                        IconButton(
                          tooltip: 'حذف از علاقه‌مندی',
                          onPressed: () async {
                            await _api.deleteFavorite(item.ataCode);
                            if (mounted) await _refresh();
                          },
                          icon: const Icon(Icons.favorite, color: AtaColors.red),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  Color _hex(String? value) {
    if (value == null || value.isEmpty) return const Color(0xFFEAEAEA);
    final raw = value.replaceFirst('#', '');
    try { return Color(int.parse('FF$raw', radix: 16)); } catch (_) { return const Color(0xFFEAEAEA); }
  }
}
