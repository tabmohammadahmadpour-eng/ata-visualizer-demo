import 'dart:io';
import 'package:flutter/material.dart';

import '../../core/services/image_acquisition_service.dart';
import '../../core/services/project_local_store.dart';
import '../../core/services/user_library_api_service.dart';
import '../../core/models/saved_project.dart';
import '../../core/theme/ata_theme.dart';
import '../../widgets/ata_logo_mark.dart';
import '../colors/color_picker_page.dart';
import '../projects/projects_page.dart';
import '../projects/favorites_page.dart';
import '../profile/profile_page.dart';
import '../visualizer/wall_selection_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _images = ImageAcquisitionService();
  final _library = UserLibraryApiService();
  final _localProjects = ProjectLocalStore();
  late Future<List<SavedProject>> _recentProjects = _library.listProjects();
  bool _busy = false;

  void _refreshRecentProjects() {
    setState(() => _recentProjects = _library.listProjects());
  }

  Future<void> _openImage(Future<String?> Function() picker) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final path = await picker();
      if (!mounted || path == null) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => WallSelectionPage(imagePath: path)),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('دسترسی به تصویر انجام نشد. مجوز دوربین/گالری را بررسی کنید.')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        bottomNavigationBar: NavigationBar(
          selectedIndex: 0,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'پروژه‌های من'),
            NavigationDestination(icon: Icon(Icons.radio_button_checked), label: 'انتخاب رنگ'),
            NavigationDestination(icon: Icon(Icons.favorite_border), label: 'علاقه‌مندی‌ها'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'پروفایل'),
          ],
          onDestinationSelected: (i) {
            if (i == 1) {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ProjectsPage()))
                  .then((_) { if (mounted) _refreshRecentProjects(); });
            }
            if (i == 2) Navigator.push(context, MaterialPageRoute(builder: (_) => const ColorPickerPage()));
            if (i == 3) Navigator.push(context, MaterialPageRoute(builder: (_) => const FavoritesPage()));
            if (i == 4) Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage()));
          },
        ),
        body: SafeArea(
          child: Stack(
            children: [
              ListView(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
                children: [
                  const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Icon(Icons.menu), AtaLogoMark(size: 76), Icon(Icons.notifications_none),
                  ]),
                  const SizedBox(height: 22),
                  const Text('سلام!', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  const Text('به ATA Visualizer خوش آمدید', style: TextStyle(color: AtaColors.muted)),
                  const SizedBox(height: 20),
                  _actionCard(
                    icon: Icons.camera_alt_outlined,
                    title: 'از دوربین عکس بگیرید',
                    subtitle: 'یک عکس تازه از فضای خود ثبت کنید',
                    accent: AtaColors.blue,
                    onTap: () => _openImage(_images.takePhoto),
                  ),
                  const SizedBox(height: 14),
                  _actionCard(
                    icon: Icons.photo_library_outlined,
                    title: 'از گالری انتخاب کنید',
                    subtitle: 'عکس موجود را انتخاب و دیوار را مشخص کنید',
                    accent: AtaColors.red,
                    onTap: () => _openImage(_images.pickFromGallery),
                  ),
                  const SizedBox(height: 28),
                  const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('پروژه‌های اخیر شما', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    Text('همه', style: TextStyle(color: AtaColors.blue, fontWeight: FontWeight.w700)),
                  ]),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 160,
                    child: FutureBuilder<List<SavedProject>>(
                      future: _recentProjects,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState != ConnectionState.done) {
                          return const Center(child: CircularProgressIndicator());
                        }
                        final projects = (snapshot.data ?? const <SavedProject>[]).take(3).toList();
                        if (projects.isEmpty) {
                          return Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: AtaColors.border)),
                            child: const Text('هنوز پروژه‌ای ذخیره نکرده‌اید.', style: TextStyle(color: AtaColors.muted)),
                          );
                        }
                        return ListView.separated(
                          scrollDirection: Axis.horizontal,
                          reverse: true,
                          itemCount: projects.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (_, i) => _recentProjectCard(projects[i]),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 24),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ColorPickerPage())),
                    icon: const Icon(Icons.palette_outlined),
                    label: const Text('مشاهده کالیته بدون عکس'),
                    style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)),
                  ),
                ],
              ),
              if (_busy)
                Positioned.fill(
                  child: ColoredBox(
                    color: Colors.white.withValues(alpha: .72),
                    child: const Center(child: CircularProgressIndicator()),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _recentProjectCard(SavedProject project) {
    return FutureBuilder<LocalProjectData>(
      future: _localProjects.read(project.id),
      builder: (context, snapshot) {
        final local = snapshot.data;
        return InkWell(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ProjectsPage()))
                .then((_) { if (mounted) _refreshRecentProjects(); });
          },
          borderRadius: BorderRadius.circular(20),
          child: Container(
            width: 158,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: AtaColors.border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox.expand(
                    child: local?.hasImage == true
                        ? Image.file(File(local!.imagePath!), fit: BoxFit.cover)
                        : ColoredBox(color: _projectColor(project.hex), child: const Icon(Icons.format_paint_outlined, color: Colors.white)),
                  ),
                ),
              ),
              const SizedBox(height: 7),
              Text(project.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(project.ataCode, style: const TextStyle(color: AtaColors.blue, fontSize: 11, fontWeight: FontWeight.w700)),
            ]),
          ),
        );
      },
    );
  }

  Color _projectColor(String? hex) {
    if (hex == null) return const Color(0xFFB9B9B9);
    try { return Color(int.parse('FF${hex.replaceFirst('#', '')}', radix: 16)); } catch (_) { return const Color(0xFFB9B9B9); }
  }

  Widget _actionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: AtaColors.border)),
        child: Row(children: [
          Container(width: 58, height: 58, decoration: BoxDecoration(color: accent, shape: BoxShape.circle), child: Icon(icon, color: Colors.white)),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(subtitle, style: const TextStyle(color: AtaColors.muted, fontSize: 13)),
          ])),
          const Icon(Icons.chevron_left),
        ]),
      ),
    );
  }
}
