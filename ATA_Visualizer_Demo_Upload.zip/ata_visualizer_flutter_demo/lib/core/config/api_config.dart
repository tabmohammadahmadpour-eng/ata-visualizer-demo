class ApiConfig {
  ApiConfig._();

  /// Android emulator default. Override for a physical phone / production:
  /// flutter run --dart-define=ATA_API_BASE_URL=https://api.example.com
  static const baseUrl = String.fromEnvironment(
    'ATA_API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000',
  );
}
