class AppConfig {
  const AppConfig._();

  static const bool demoMode = bool.fromEnvironment(
    'ATA_DEMO_MODE',
    defaultValue: false,
  );

  static const String demoOtpCode = '12345';
  static const String demoToken = 'ata-demo-token';
}
