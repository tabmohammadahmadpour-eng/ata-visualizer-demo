import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/color_family.dart';

/// Local JSON repository used by the first installable prototype.
///
/// Later this class can be replaced by an API-backed repository without
/// changing the color-picker UI. That is intentional: new ATA colors should
/// be data changes, not Flutter code changes.
class AtaPaletteRepository {
  final String assetPath;

  const AtaPaletteRepository({this.assetPath = 'assets/data/ata_colors_seed.json'});

  Future<List<ColorFamily>> loadFamilies() async {
    final raw = await rootBundle.loadString(assetPath);
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    final colors = (decoded['colors'] as List<dynamic>)
        .map((e) => AtaPaintColor.fromJson(e as Map<String, dynamic>))
        .where((c) => c.isActive)
        .toList();

    final families = _familyDefinitions.map((definition) {
      final familyColors = colors
          .where((c) => c.familyId == definition.id)
          .toList()
        ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
      return ColorFamily(
        id: definition.id,
        name: definition.name,
        icon: definition.icon,
        accent: definition.accent,
        sortOrder: definition.sortOrder,
        colors: familyColors,
      );
    }).where((f) => f.colors.isNotEmpty).toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

    return families;
  }
  Future<AtaPaintColor?> findByCode(String ataCode) async {
    final families = await loadFamilies();
    for (final family in families) {
      for (final color in family.colors) {
        if (color.code == ataCode) return color;
      }
    }
    return null;
  }

}

class _FamilyDefinition {
  final String id;
  final String name;
  final IconData icon;
  final Color accent;
  final int sortOrder;

  const _FamilyDefinition(this.id, this.name, this.icon, this.accent, this.sortOrder);
}

const _familyDefinitions = <_FamilyDefinition>[
  _FamilyDefinition('white-light', 'سفید و روشن', Icons.light_mode_outlined, Color(0xFFF1F0EA), 10),
  _FamilyDefinition('cream-nude', 'کرم و نود', Icons.water_drop_outlined, Color(0xFFD8C6A5), 20),
  _FamilyDefinition('yellow-gold', 'زرد و طلایی', Icons.wb_sunny_outlined, Color(0xFFFFC107), 30),
  _FamilyDefinition('peach-pink-rose', 'هلویی، صورتی و رز', Icons.local_florist_outlined, Color(0xFFE7B9B1), 40),
  _FamilyDefinition('red-brick-wine', 'قرمز، آجری و شرابی', Icons.brush_outlined, Color(0xFFE0131A), 50),
  _FamilyDefinition('purple-lilac-blue', 'بنفش، یاسی و آبی', Icons.palette_outlined, Color(0xFF0057D9), 60),
  _FamilyDefinition('green-teal', 'سبز، فیروزه‌ای و آبی‌سبز', Icons.eco_outlined, Color(0xFF198F82), 70),
  _FamilyDefinition('gray-neutral', 'خاکستری و خنثی', Icons.cloud_outlined, Color(0xFF777A7D), 80),
  _FamilyDefinition('brown-dark', 'قهوه‌ای و تیره', Icons.layers_outlined, Color(0xFF674528), 90),
];
