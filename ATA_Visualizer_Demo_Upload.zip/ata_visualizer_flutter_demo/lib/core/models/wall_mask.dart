import 'dart:collection';
import 'dart:typed_data';

import 'package:flutter/material.dart';

/// Binary wall mask stored on a small normalized grid.
///
/// A value of 1 means that cell belongs to the wall. Keeping the mask in
/// normalized model-space lets the same segmentation be rendered on any
/// screen size while preserving holes around windows, televisions and other
/// non-wall objects.
class WallMask {
  final int width;
  final int height;
  final Uint8List data;

  WallMask({
    required this.width,
    required this.height,
    required Uint8List data,
  }) : data = Uint8List.fromList(data) {
    if (width <= 0 || height <= 0 || data.length != width * height) {
      throw ArgumentError('ابعاد ماسک دیوار نامعتبر است.');
    }
  }

  bool get isValid => data.any((v) => v != 0);

  int get activeCellCount => data.fold<int>(0, (sum, v) => sum + (v == 0 ? 0 : 1));

  double get coverage => activeCellCount / data.length;

  bool containsCell(int x, int y) {
    if (x < 0 || y < 0 || x >= width || y >= height) return false;
    return data[y * width + x] != 0;
  }

  bool containsNormalized(Offset p) {
    final x = (p.dx.clamp(0.0, .999999) * width).floor();
    final y = (p.dy.clamp(0.0, .999999) * height).floor();
    return containsCell(x, y);
  }

  /// Returns a new mask after painting a circular brush in normalized image
  /// coordinates. [include] adds wall pixels; false erases them.
  WallMask paintCircle({
    required Offset normalizedCenter,
    required double normalizedRadius,
    required bool include,
  }) {
    final next = Uint8List.fromList(data);
    final cx = normalizedCenter.dx * width;
    final cy = normalizedCenter.dy * height;
    final radiusPx = normalizedRadius * (width < height ? width : height);
    final r2 = radiusPx * radiusPx;

    final minX = (cx - radiusPx).floor().clamp(0, width - 1);
    final maxX = (cx + radiusPx).ceil().clamp(0, width - 1);
    final minY = (cy - radiusPx).floor().clamp(0, height - 1);
    final maxY = (cy + radiusPx).ceil().clamp(0, height - 1);

    for (int y = minY; y <= maxY; y++) {
      for (int x = minX; x <= maxX; x++) {
        final dx = x + .5 - cx;
        final dy = y + .5 - cy;
        if (dx * dx + dy * dy <= r2) {
          next[y * width + x] = include ? 1 : 0;
        }
      }
    }
    return WallMask(width: width, height: height, data: next);
  }

  /// Keeps only the largest 4-connected component. This removes small
  /// segmentation islands that frequently appear around picture frames,
  /// furniture edges and reflections.
  WallMask keepLargestConnectedComponent() {
    final visited = Uint8List(data.length);
    List<int> best = const [];
    final queue = ListQueue<int>();

    for (int start = 0; start < data.length; start++) {
      if (data[start] == 0 || visited[start] != 0) continue;
      final component = <int>[];
      visited[start] = 1;
      queue.add(start);

      while (queue.isNotEmpty) {
        final i = queue.removeFirst();
        component.add(i);
        final x = i % width;
        final y = i ~/ width;
        final neighbors = <int>[
          if (x > 0) i - 1,
          if (x < width - 1) i + 1,
          if (y > 0) i - width,
          if (y < height - 1) i + width,
        ];
        for (final n in neighbors) {
          if (data[n] != 0 && visited[n] == 0) {
            visited[n] = 1;
            queue.add(n);
          }
        }
      }
      if (component.length > best.length) best = component;
    }

    final output = Uint8List(data.length);
    for (final i in best) {
      output[i] = 1;
    }
    return WallMask(width: width, height: height, data: output);
  }

  WallMask copy() => WallMask(width: width, height: height, data: data);
}
