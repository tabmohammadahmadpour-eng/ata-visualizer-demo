class AuthUser {
  final String id;
  final String phone;
  final String phoneE164;
  final bool smsConsent;
  final bool pushConsent;

  const AuthUser({
    required this.id,
    required this.phone,
    required this.phoneE164,
    required this.smsConsent,
    required this.pushConsent,
  });

  factory AuthUser.fromJson(Map<String, dynamic> json) {
    return AuthUser(
      id: json['id'] as String,
      phone: json['phone'] as String,
      phoneE164: json['phone_e164'] as String,
      smsConsent: json['sms_consent'] as bool? ?? false,
      pushConsent: json['push_consent'] as bool? ?? false,
    );
  }
}

class AuthSession {
  final String accessToken;
  final int expiresInSeconds;
  final AuthUser user;

  const AuthSession({
    required this.accessToken,
    required this.expiresInSeconds,
    required this.user,
  });

  factory AuthSession.fromJson(Map<String, dynamic> json) {
    return AuthSession(
      accessToken: json['access_token'] as String,
      expiresInSeconds: json['expires_in_seconds'] as int,
      user: AuthUser.fromJson(json['user'] as Map<String, dynamic>),
    );
  }
}

class OtpRequestResult {
  final String challengeId;
  final int expiresInSeconds;
  final int resendAfterSeconds;
  final String? debugCode;

  const OtpRequestResult({
    required this.challengeId,
    required this.expiresInSeconds,
    required this.resendAfterSeconds,
    this.debugCode,
  });

  factory OtpRequestResult.fromJson(Map<String, dynamic> json) {
    return OtpRequestResult(
      challengeId: json['challenge_id'] as String,
      expiresInSeconds: json['expires_in_seconds'] as int,
      resendAfterSeconds: json['resend_after_seconds'] as int,
      debugCode: json['debug_code'] as String?,
    );
  }
}
