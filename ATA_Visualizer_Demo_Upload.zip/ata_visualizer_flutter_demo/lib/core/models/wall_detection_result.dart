import 'wall_mask.dart';
import 'wall_polygon.dart';

enum WallDetectionMethod {
  smartLocal,
  aiModel,
  manual,
}

/// Vendor-neutral result returned by any wall detection engine.
///
/// AI segmentation returns a pixel mask so holes around objects are preserved.
/// The lightweight fallback and manual mode may still return a polygon.
class WallDetectionResult {
  final WallMask? mask;
  final WallPolygon? polygon;
  final double? confidence;
  final WallDetectionMethod method;
  final String? modelLabel;

  const WallDetectionResult({
    this.mask,
    this.polygon,
    this.confidence,
    required this.method,
    this.modelLabel,
  });

  bool get isValid => mask?.isValid == true || polygon?.isValid == true;
}
