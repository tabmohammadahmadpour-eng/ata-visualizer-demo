import 'package:flutter/material.dart';

/// A wall selection stored as normalized points (0..1) relative to the image.
///
/// Normalized storage means the polygon remains valid across phones and
/// different widget sizes. It can later be replaced by an AI segmentation mask
/// without changing the visualizer page contract.
class WallPolygon {
  final List<Offset> points;

  const WallPolygon(this.points);

  bool get isValid => points.length >= 3;

  List<Offset> denormalize(Size size) => points
      .map((p) => Offset(p.dx * size.width, p.dy * size.height))
      .toList(growable: false);

  static Offset normalize(Offset point, Size size) {
    if (size.width == 0 || size.height == 0) return Offset.zero;
    return Offset(
      (point.dx / size.width).clamp(0.0, 1.0),
      (point.dy / size.height).clamp(0.0, 1.0),
    );
  }
}
