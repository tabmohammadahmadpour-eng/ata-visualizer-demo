class SegmentationModelManifest {
  final int schemaVersion;
  final String modelId;
  final String assetPath;
  final String task;
  final int inputWidth;
  final int inputHeight;
  final int inputChannels;
  final String inputDtype;
  final String normalization;
  final String outputKind;
  final int wallClassIndex;
  final double threshold;
  final bool keepLargestComponent;
  final double minWallCoverage;
  final double maxWallCoverage;
  final String licenseStatus;
  final String? licenseNote;

  const SegmentationModelManifest({
    required this.schemaVersion,
    required this.modelId,
    required this.assetPath,
    required this.task,
    required this.inputWidth,
    required this.inputHeight,
    required this.inputChannels,
    required this.inputDtype,
    required this.normalization,
    required this.outputKind,
    required this.wallClassIndex,
    required this.threshold,
    required this.keepLargestComponent,
    required this.minWallCoverage,
    required this.maxWallCoverage,
    required this.licenseStatus,
    this.licenseNote,
  });

  factory SegmentationModelManifest.fromJson(Map<String, dynamic> json) {
    final input = (json['input'] as Map?)?.cast<String, dynamic>() ?? const {};
    final output = (json['output'] as Map?)?.cast<String, dynamic>() ?? const {};
    final post = (json['postprocess'] as Map?)?.cast<String, dynamic>() ?? const {};
    final license = (json['license'] as Map?)?.cast<String, dynamic>() ?? const {};

    return SegmentationModelManifest(
      schemaVersion: (json['schema_version'] as num?)?.toInt() ?? 1,
      modelId: json['model_id']?.toString() ?? 'unknown',
      assetPath: json['asset_path']?.toString() ?? 'assets/models/wall_segmenter.tflite',
      task: json['task']?.toString() ?? 'binary_wall_segmentation',
      inputWidth: (input['width'] as num?)?.toInt() ?? 256,
      inputHeight: (input['height'] as num?)?.toInt() ?? 256,
      inputChannels: (input['channels'] as num?)?.toInt() ?? 3,
      inputDtype: input['dtype']?.toString() ?? 'float32',
      normalization: input['normalization']?.toString() ?? 'zero_to_one',
      outputKind: output['kind']?.toString() ?? 'binary_probability',
      wallClassIndex: (output['wall_class_index'] as num?)?.toInt() ?? 1,
      threshold: (output['threshold'] as num?)?.toDouble() ?? .5,
      keepLargestComponent: post['keep_largest_component'] as bool? ?? true,
      minWallCoverage: (post['min_wall_coverage'] as num?)?.toDouble() ?? .035,
      maxWallCoverage: (post['max_wall_coverage'] as num?)?.toDouble() ?? .92,
      licenseStatus: license['status']?.toString() ?? 'unknown',
      licenseNote: license['note']?.toString(),
    );
  }

  bool get isProductionWeightApproved => licenseStatus == 'approved_for_production';
}
