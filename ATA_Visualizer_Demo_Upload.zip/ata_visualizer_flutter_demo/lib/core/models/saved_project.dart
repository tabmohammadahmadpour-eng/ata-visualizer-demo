class SavedProject {
  final String id;
  final String title;
  final String ataCode;
  final String nameFa;
  final String? familyId;
  final String? familyName;
  final String? rgb;
  final String? hex;
  final bool hasImage;
  final bool hasAiMask;
  final DateTime createdAt;
  final DateTime updatedAt;

  const SavedProject({
    required this.id,
    required this.title,
    required this.ataCode,
    required this.nameFa,
    required this.hasImage,
    required this.hasAiMask,
    required this.createdAt,
    required this.updatedAt,
    this.familyId,
    this.familyName,
    this.rgb,
    this.hex,
  });

  factory SavedProject.fromJson(Map<String, dynamic> json) => SavedProject(
        id: json['id'] as String,
        title: json['title'] as String,
        ataCode: json['ata_code'] as String,
        nameFa: json['name_fa'] as String,
        familyId: json['family_id'] as String?,
        familyName: json['family_name'] as String?,
        rgb: json['rgb'] as String?,
        hex: json['hex'] as String?,
        hasImage: json['has_image'] as bool? ?? false,
        hasAiMask: json['has_ai_mask'] as bool? ?? false,
        createdAt: DateTime.parse(json['created_at'] as String),
        updatedAt: DateTime.parse(json['updated_at'] as String),
      );
}

class FavoriteColorRecord {
  final String id;
  final String ataCode;
  final String nameFa;
  final String? familyId;
  final String? familyName;
  final String? rgb;
  final String? hex;
  final DateTime createdAt;

  const FavoriteColorRecord({
    required this.id,
    required this.ataCode,
    required this.nameFa,
    required this.createdAt,
    this.familyId,
    this.familyName,
    this.rgb,
    this.hex,
  });

  factory FavoriteColorRecord.fromJson(Map<String, dynamic> json) => FavoriteColorRecord(
        id: json['id'] as String,
        ataCode: json['ata_code'] as String,
        nameFa: json['name_fa'] as String,
        familyId: json['family_id'] as String?,
        familyName: json['family_name'] as String?,
        rgb: json['rgb'] as String?,
        hex: json['hex'] as String?,
        createdAt: DateTime.parse(json['created_at'] as String),
      );
}
