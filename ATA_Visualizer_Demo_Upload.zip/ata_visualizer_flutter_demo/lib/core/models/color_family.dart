import 'package:flutter/material.dart';

/// A single ATA paint color.
///
/// The app intentionally stores no English display name. [sourceCode] is kept
/// only as an internal catalog reference so the ATA code can always be traced
/// back to the printed source catalog when data is audited.
class AtaPaintColor {
  final String id;
  final String sourceCode;
  final String code;
  final int codeNumber;
  final String codeSuffix;
  final String nameFa;
  final String familyId;
  final String? subfamily;
  final Color color;
  final String hex;
  final String rgb;
  final int catalogPage;
  final int sortOrder;
  final bool isActive;
  final bool isFeatured;
  final ColorAccuracy accuracy;

  const AtaPaintColor({
    required this.id,
    required this.sourceCode,
    required this.code,
    required this.codeNumber,
    required this.codeSuffix,
    required this.nameFa,
    required this.familyId,
    required this.color,
    required this.hex,
    required this.rgb,
    required this.catalogPage,
    required this.sortOrder,
    this.subfamily,
    this.isActive = true,
    this.isFeatured = false,
    this.accuracy = ColorAccuracy.provisional,
  });

  factory AtaPaintColor.fromJson(Map<String, dynamic> json) {
    final hex = (json['hex'] as String).toUpperCase();
    return AtaPaintColor(
      id: json['id'] as String,
      sourceCode: json['source_code'] as String,
      code: json['ata_code'] as String,
      codeNumber: json['code_number'] as int,
      codeSuffix: (json['code_suffix'] as String?) ?? '',
      nameFa: json['name_fa'] as String,
      familyId: json['family_id'] as String,
      subfamily: json['subfamily'] as String?,
      color: _hexToColor(hex),
      hex: hex,
      rgb: json['rgb'] as String,
      catalogPage: json['catalog_page'] as int,
      sortOrder: json['sort_order'] as int,
      isActive: (json['is_active'] as bool?) ?? true,
      isFeatured: (json['is_featured'] as bool?) ?? false,
      accuracy: (json['color_accuracy'] as String?) == 'calibrated'
          ? ColorAccuracy.calibrated
          : ColorAccuracy.provisional,
    );
  }

  static Color _hexToColor(String hex) {
    final normalized = hex.replaceFirst('#', '');
    return Color(int.parse('FF$normalized', radix: 16));
  }
}

enum ColorAccuracy { provisional, calibrated }

class ColorFamily {
  final String id;
  final String name;
  final IconData icon;
  final Color accent;
  final int sortOrder;
  final List<AtaPaintColor> colors;

  const ColorFamily({
    required this.id,
    required this.name,
    required this.icon,
    required this.accent,
    required this.sortOrder,
    required this.colors,
  });
}
