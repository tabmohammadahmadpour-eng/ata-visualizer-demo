import 'dart:io';
import 'dart:ui' as ui;

class ImageMetadataService {
  static Future<ui.Size> readPixelSize(String path) async {
    final bytes = await File(path).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final image = frame.image;
    final result = ui.Size(image.width.toDouble(), image.height.toDouble());
    image.dispose();
    codec.dispose();
    return result;
  }
}
