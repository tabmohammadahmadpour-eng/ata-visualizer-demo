import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/api_config.dart';
import '../config/app_config.dart';
import '../models/auth_session.dart';

class AuthApiException implements Exception {
  final String message;
  final int? statusCode;

  const AuthApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class AuthApiService {
  final http.Client _client;
  final String baseUrl;

  AuthApiService({http.Client? client, String? baseUrl})
      : _client = client ?? http.Client(),
        baseUrl = baseUrl ?? ApiConfig.baseUrl;

  Future<OtpRequestResult> requestOtp({
    required String phone,
    required bool smsConsent,
  }) async {
    if (AppConfig.demoMode) {
      final normalized = _normalizeIranPhone(phone);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('demo_phone', normalized.$1);
      await prefs.setString('demo_phone_e164', normalized.$2);
      await prefs.setBool('demo_sms_consent', smsConsent);
      return const OtpRequestResult(
        challengeId: 'demo-challenge',
        expiresInSeconds: 600,
        resendAfterSeconds: 10,
        debugCode: AppConfig.demoOtpCode,
      );
    }

    final json = await _request(
      'POST',
      '/auth/request-otp',
      body: {'phone': phone, 'sms_consent': smsConsent},
    );
    return OtpRequestResult.fromJson(json);
  }

  Future<AuthSession> verifyOtp({
    required String phone,
    required String code,
  }) async {
    if (AppConfig.demoMode) {
      if (code.trim() != AppConfig.demoOtpCode) {
        throw const AuthApiException('کد آزمایشی درست نیست. برای نسخه دمو 12345 را وارد کنید.');
      }
      final prefs = await SharedPreferences.getInstance();
      final normalized = _normalizeIranPhone(phone);
      await prefs.setString('demo_phone', normalized.$1);
      await prefs.setString('demo_phone_e164', normalized.$2);
      final user = await _demoUser();
      return AuthSession(
        accessToken: AppConfig.demoToken,
        expiresInSeconds: 60 * 60 * 24 * 365,
        user: user,
      );
    }

    final json = await _request(
      'POST',
      '/auth/verify-otp',
      body: {'phone': phone, 'code': code},
    );
    return AuthSession.fromJson(json);
  }

  Future<AuthUser> me(String accessToken) async {
    if (AppConfig.demoMode) {
      if (accessToken.isEmpty) throw const AuthApiException('نشست آزمایشی پیدا نشد.');
      return _demoUser();
    }
    final json = await _request('GET', '/auth/me', token: accessToken);
    return AuthUser.fromJson(json);
  }

  Future<AuthUser> updatePreferences({
    required String accessToken,
    bool? smsConsent,
    bool? pushConsent,
  }) async {
    if (AppConfig.demoMode) {
      final prefs = await SharedPreferences.getInstance();
      if (smsConsent != null) await prefs.setBool('demo_sms_consent', smsConsent);
      if (pushConsent != null) await prefs.setBool('demo_push_consent', pushConsent);
      return _demoUser();
    }

    final json = await _request(
      'PATCH',
      '/auth/preferences',
      token: accessToken,
      body: <String, dynamic>{
        if (smsConsent != null) 'sms_consent': smsConsent,
        if (pushConsent != null) 'push_consent': pushConsent,
      },
    );
    return AuthUser.fromJson(json);
  }

  Future<void> logout(String accessToken) async {
    if (AppConfig.demoMode) return;
    await _request('POST', '/auth/logout', token: accessToken, expectNoContent: true);
  }

  Future<AuthUser> _demoUser() async {
    final prefs = await SharedPreferences.getInstance();
    final phone = prefs.getString('demo_phone') ?? '09123456789';
    final phoneE164 = prefs.getString('demo_phone_e164') ?? '+989123456789';
    return AuthUser(
      id: 'demo-user',
      phone: phone,
      phoneE164: phoneE164,
      smsConsent: prefs.getBool('demo_sms_consent') ?? false,
      pushConsent: prefs.getBool('demo_push_consent') ?? false,
    );
  }

  (String, String) _normalizeIranPhone(String input) {
    var value = input.replaceAll(RegExp(r'[^0-9+]'), '');
    if (value.startsWith('0098')) value = '+98${value.substring(4)}';
    if (value.startsWith('98') && !value.startsWith('+')) value = '+$value';
    if (value.startsWith('+98')) value = '0${value.substring(3)}';
    if (!RegExp(r'^09\d{9}$').hasMatch(value)) {
      throw const AuthApiException('شماره موبایل را به شکل 09xxxxxxxxx وارد کنید.');
    }
    return (value, '+98${value.substring(1)}');
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    String? token,
    bool expectNoContent = false,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (token != null) headers['Authorization'] = 'Bearer $token';

    late http.Response response;
    try {
      if (method == 'POST') {
        response = await _client.post(uri, headers: headers, body: body == null ? null : jsonEncode(body));
      } else if (method == 'GET') {
        response = await _client.get(uri, headers: headers);
      } else if (method == 'PATCH') {
        response = await _client.patch(uri, headers: headers, body: body == null ? null : jsonEncode(body));
      } else {
        throw StateError('Unsupported HTTP method: $method');
      }
    } catch (_) {
      throw const AuthApiException('ارتباط با سرور برقرار نشد. اینترنت یا آدرس سرور را بررسی کنید.');
    }

    if (expectNoContent && response.statusCode >= 200 && response.statusCode < 300) {
      return const {};
    }

    Map<String, dynamic> decoded = const {};
    if (response.body.isNotEmpty) {
      final raw = jsonDecode(utf8.decode(response.bodyBytes));
      if (raw is Map<String, dynamic>) decoded = raw;
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final detail = decoded['detail'];
      throw AuthApiException(
        detail is String ? detail : 'خطایی در ارتباط با سرور رخ داد.',
        statusCode: response.statusCode,
      );
    }
    return decoded;
  }
}
