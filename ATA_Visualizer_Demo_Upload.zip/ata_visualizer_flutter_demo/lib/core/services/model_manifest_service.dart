import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/segmentation_model_manifest.dart';

class ModelManifestService {
  final String manifestAssetPath;

  const ModelManifestService({
    this.manifestAssetPath = 'assets/models/model_manifest.json',
  });

  Future<SegmentationModelManifest> load() async {
    final raw = await rootBundle.loadString(manifestAssetPath);
    final json = jsonDecode(raw) as Map<String, dynamic>;
    return SegmentationModelManifest.fromJson(json);
  }
}
