import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureSessionStore {
  static const _tokenKey = 'ata_access_token';
  final FlutterSecureStorage _storage;

  const SecureSessionStore({FlutterSecureStorage storage = const FlutterSecureStorage()}) : _storage = storage;

  Future<void> saveToken(String token) => _storage.write(key: _tokenKey, value: token);
  Future<String?> readToken() => _storage.read(key: _tokenKey);
  Future<void> clear() => _storage.delete(key: _tokenKey);
}
