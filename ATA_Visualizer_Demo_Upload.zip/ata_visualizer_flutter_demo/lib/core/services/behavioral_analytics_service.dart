import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';
import '../config/app_config.dart';
import '../models/color_family.dart';
import 'secure_session_store.dart';

/// Sends privacy-conscious product analytics to the ATA backend.
///
/// Analytics are best-effort: a tracking failure must never block color
/// selection or the visualizer. Only product behavior and color metadata are
/// sent. Room photos are not uploaded by this service.
class BehavioralAnalyticsService {
  BehavioralAnalyticsService._();

  static final BehavioralAnalyticsService instance = BehavioralAnalyticsService._();

  final http.Client _client = http.Client();
  final SecureSessionStore _sessionStore = const SecureSessionStore();
  final Map<String, DateTime> _lastColorViewAt = <String, DateTime>{};

  static const Duration _viewDedupWindow = Duration(seconds: 8);

  Future<void> trackColorViewed(
    AtaPaintColor color, {
    String? familyName,
    String source = 'color_picker',
  }) async {
    final now = DateTime.now();
    final last = _lastColorViewAt[color.code];
    if (last != null && now.difference(last) < _viewDedupWindow) return;
    _lastColorViewAt[color.code] = now;
    await _send(
      'color_viewed',
      _colorMetadata(color, familyName: familyName, source: source),
    );
  }

  Future<void> trackColorApplied(
    AtaPaintColor color, {
    String? familyName,
    String source = 'color_picker',
  }) =>
      _send(
        'color_applied',
        _colorMetadata(color, familyName: familyName, source: source),
      );

  Future<void> trackColorSaved(
    AtaPaintColor color, {
    String? familyName,
    String source = 'favorite',
  }) =>
      _send(
        'color_saved',
        _colorMetadata(color, familyName: familyName, source: source),
      );

  Future<void> trackColorUnsaved(
    AtaPaintColor color, {
    String? familyName,
    String source = 'favorite',
  }) =>
      _send(
        'color_unsaved',
        _colorMetadata(color, familyName: familyName, source: source),
      );

  Future<void> trackProjectSaveRequested(
    AtaPaintColor color, {
    String? familyName,
    required bool hasImage,
    required bool hasAiMask,
  }) =>
      _send(
        'project_save_requested',
        <String, Object?>{
          ..._colorMetadata(color, familyName: familyName, source: 'visualizer'),
          'has_image': hasImage,
          'has_ai_mask': hasAiMask,
        },
      );

  Map<String, Object?> _colorMetadata(
    AtaPaintColor color, {
    String? familyName,
    required String source,
  }) {
    return <String, Object?>{
      'ata_code': color.code,
      'name_fa': color.nameFa,
      'family_id': color.familyId,
      if (familyName != null && familyName.isNotEmpty) 'family_name': familyName,
      'rgb': color.rgb,
      'hex': color.hex,
      'source': source,
    };
  }

  Future<void> _send(String eventType, Map<String, Object?> metadata) async {
    if (AppConfig.demoMode) return;
    try {
      final token = await _sessionStore.readToken();
      if (token == null || token.isEmpty) return;

      final response = await _client.post(
        Uri.parse('${ApiConfig.baseUrl}/events'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode(<String, Object?>{
          'event_type': eventType,
          'metadata': metadata,
        }),
      );

      // Analytics are intentionally non-blocking. Any non-2xx response is
      // ignored here; server-side monitoring will surface persistent errors.
      if (response.statusCode < 200 || response.statusCode >= 300) return;
    } catch (_) {
      // Never interrupt the user experience because analytics are unavailable.
    }
  }
}
