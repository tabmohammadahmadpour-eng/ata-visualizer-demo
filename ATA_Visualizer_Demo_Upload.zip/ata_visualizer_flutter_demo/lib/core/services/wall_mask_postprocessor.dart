import 'dart:typed_data';

import '../models/wall_mask.dart';

class WallMaskPostprocessor {
  const WallMaskPostprocessor();

  WallMask fromBinaryProbabilities({
    required List<double> probabilities,
    required int width,
    required int height,
    double threshold = .5,
    bool keepLargestComponent = true,
  }) {
    if (probabilities.length != width * height) {
      throw ArgumentError('طول خروجی مدل با ابعاد ماسک هم‌خوان نیست.');
    }
    final data = Uint8List(probabilities.length);
    for (int i = 0; i < probabilities.length; i++) {
      data[i] = probabilities[i] >= threshold ? 1 : 0;
    }
    var mask = WallMask(width: width, height: height, data: data);
    if (keepLargestComponent) {
      mask = mask.keepLargestConnectedComponent();
    }
    return mask;
  }

  WallMask fromClassMap({
    required List<int> classes,
    required int width,
    required int height,
    required int wallClassIndex,
    bool keepLargestComponent = true,
  }) {
    if (classes.length != width * height) {
      throw ArgumentError('طول خروجی مدل با ابعاد ماسک هم‌خوان نیست.');
    }
    final data = Uint8List(classes.length);
    for (int i = 0; i < classes.length; i++) {
      data[i] = classes[i] == wallClassIndex ? 1 : 0;
    }
    var mask = WallMask(width: width, height: height, data: data);
    if (keepLargestComponent) {
      mask = mask.keepLargestConnectedComponent();
    }
    return mask;
  }
}
