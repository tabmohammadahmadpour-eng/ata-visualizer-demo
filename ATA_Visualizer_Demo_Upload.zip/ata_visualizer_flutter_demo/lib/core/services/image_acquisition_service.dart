import 'package:image_picker/image_picker.dart';

class ImageAcquisitionService {
  final ImagePicker _picker;

  ImageAcquisitionService({ImagePicker? picker}) : _picker = picker ?? ImagePicker();

  Future<String?> pickFromGallery() async {
    final image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 94,
      maxWidth: 2600,
    );
    return image?.path;
  }

  Future<String?> takePhoto() async {
    final image = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 94,
      maxWidth: 2600,
      preferredCameraDevice: CameraDevice.rear,
    );
    return image?.path;
  }
}
