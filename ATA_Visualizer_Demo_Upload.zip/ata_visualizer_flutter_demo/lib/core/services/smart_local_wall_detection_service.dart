import 'dart:collection';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../models/wall_detection_result.dart';
import '../models/wall_polygon.dart';
import 'wall_detection_service.dart';

/// Lightweight offline wall suggestion used by the v0.5 prototype.
///
/// This is intentionally NOT presented as the final AI model. It downsamples
/// the room photo, tests several likely wall seed points, region-grows the most
/// visually coherent large area, then converts its boundary to a simplified
/// polygon. The user can always correct the suggestion manually.
class SmartLocalWallDetectionService implements WallDetectionService {
  final int targetWidth;
  final double seedDistanceThreshold;
  final double neighborDistanceThreshold;
  final int maxPolygonPoints;

  const SmartLocalWallDetectionService({
    this.targetWidth = 192,
    this.seedDistanceThreshold = 92,
    this.neighborDistanceThreshold = 44,
    this.maxPolygonPoints = 12,
  });

  @override
  Future<WallDetectionResult?> detectWall(String imagePath) async {
    final bytes = await File(imagePath).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes, targetWidth: targetWidth);
    final frame = await codec.getNextFrame();
    final image = frame.image;
    final byteData = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (byteData == null) {
      image.dispose();
      codec.dispose();
      return null;
    }

    final width = image.width;
    final height = image.height;
    final rgba = byteData.buffer.asUint8List();

    final seeds = <Offset>[
      const Offset(.50, .28),
      const Offset(.32, .30),
      const Offset(.68, .30),
      const Offset(.50, .42),
      const Offset(.22, .36),
      const Offset(.78, .36),
      const Offset(.38, .52),
      const Offset(.62, .52),
    ];

    Uint8List? bestMask;
    int bestCount = 0;

    for (final seed in seeds) {
      final sx = (seed.dx * (width - 1)).round();
      final sy = (seed.dy * (height - 1)).round();
      if (sy >= (height * .82).floor()) continue;

      final grown = _growRegion(
        rgba: rgba,
        width: width,
        height: height,
        seedX: sx,
        seedY: sy,
      );
      if (grown.$2 > bestCount) {
        bestMask = grown.$1;
        bestCount = grown.$2;
      }
    }

    image.dispose();
    codec.dispose();

    final minUsefulPixels = (width * height * .08).floor();
    if (bestMask == null || bestCount < minUsefulPixels) return null;

    final boundary = _boundaryPoints(bestMask, width, height);
    if (boundary.length < 3) return null;

    final hull = _convexHull(boundary);
    if (hull.length < 3) return null;

    final simplified = _samplePolygon(hull, maxPolygonPoints)
        .map((p) => Offset(
              (p.dx / (width - 1)).clamp(0.0, 1.0),
              (p.dy / (height - 1)).clamp(0.0, 1.0),
            ))
        .toList(growable: false);

    final coverage = bestCount / (width * height);
    final confidence = ((coverage - .08) / .52).clamp(.25, .82).toDouble();

    return WallDetectionResult(
      polygon: WallPolygon(simplified),
      confidence: confidence,
      method: WallDetectionMethod.smartLocal,
      modelLabel: 'local-region-grow',
    );
  }

  (Uint8List, int) _growRegion({
    required Uint8List rgba,
    required int width,
    required int height,
    required int seedX,
    required int seedY,
  }) {
    final mask = Uint8List(width * height);
    final queue = ListQueue<int>();
    final seedIndex = seedY * width + seedX;
    final seedColor = _rgbAt(rgba, seedIndex);

    queue.add(seedIndex);
    mask[seedIndex] = 1;
    int count = 1;

    while (queue.isNotEmpty) {
      final index = queue.removeFirst();
      final x = index % width;
      final y = index ~/ width;
      final current = _rgbAt(rgba, index);

      final neighbors = <int>[
        if (x > 0) index - 1,
        if (x < width - 1) index + 1,
        if (y > 0) index - width,
        if (y < height - 1) index + width,
      ];

      for (final next in neighbors) {
        if (mask[next] != 0) continue;
        final ny = next ~/ width;

        // Floors and rugs frequently dominate the lower strip and should not
        // be allowed to swallow the region in this first-pass detector.
        if (ny > height * .88) continue;

        final candidate = _rgbAt(rgba, next);
        final seedDistance = _distance(candidate, seedColor);
        final localDistance = _distance(candidate, current);

        if (seedDistance <= seedDistanceThreshold &&
            localDistance <= neighborDistanceThreshold) {
          mask[next] = 1;
          queue.add(next);
          count++;
        }
      }
    }

    return (mask, count);
  }

  List<Offset> _boundaryPoints(Uint8List mask, int width, int height) {
    final points = <Offset>[];
    for (int y = 1; y < height - 1; y++) {
      for (int x = 1; x < width - 1; x++) {
        final i = y * width + x;
        if (mask[i] == 0) continue;
        final edge = mask[i - 1] == 0 ||
            mask[i + 1] == 0 ||
            mask[i - width] == 0 ||
            mask[i + width] == 0;
        if (edge) points.add(Offset(x.toDouble(), y.toDouble()));
      }
    }
    return points;
  }

  List<Offset> _convexHull(List<Offset> points) {
    final sorted = [...points]
      ..sort((a, b) {
        final byX = a.dx.compareTo(b.dx);
        return byX != 0 ? byX : a.dy.compareTo(b.dy);
      });
    if (sorted.length <= 3) return sorted;

    double cross(Offset o, Offset a, Offset b) =>
        (a.dx - o.dx) * (b.dy - o.dy) -
        (a.dy - o.dy) * (b.dx - o.dx);

    final lower = <Offset>[];
    for (final p in sorted) {
      while (lower.length >= 2 &&
          cross(lower[lower.length - 2], lower.last, p) <= 0) {
        lower.removeLast();
      }
      lower.add(p);
    }

    final upper = <Offset>[];
    for (final p in sorted.reversed) {
      while (upper.length >= 2 &&
          cross(upper[upper.length - 2], upper.last, p) <= 0) {
        upper.removeLast();
      }
      upper.add(p);
    }

    lower.removeLast();
    upper.removeLast();
    return [...lower, ...upper];
  }

  List<Offset> _samplePolygon(List<Offset> polygon, int maxPoints) {
    if (polygon.length <= maxPoints) return polygon;
    final output = <Offset>[];
    for (int i = 0; i < maxPoints; i++) {
      final index = ((i / maxPoints) * polygon.length).floor();
      final safeIndex = index < 0 ? 0 : (index >= polygon.length ? polygon.length - 1 : index);
      output.add(polygon[safeIndex]);
    }
    return output;
  }

  (int, int, int) _rgbAt(Uint8List rgba, int pixelIndex) {
    final base = pixelIndex * 4;
    return (rgba[base], rgba[base + 1], rgba[base + 2]);
  }

  double _distance((int, int, int) a, (int, int, int) b) {
    final dr = a.$1 - b.$1;
    final dg = a.$2 - b.$2;
    final db = a.$3 - b.$3;
    return math.sqrt((dr * dr + dg * dg + db * db).toDouble());
  }
}
