import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../models/wall_mask.dart';
import '../models/wall_polygon.dart';

class LocalProjectData {
  final String? imagePath;
  final WallMask? wallMask;
  final WallPolygon? wallPolygon;

  const LocalProjectData({this.imagePath, this.wallMask, this.wallPolygon});

  bool get hasImage => imagePath != null && File(imagePath!).existsSync();
}

/// Stores private room photos only inside the app's own documents directory.
///
/// The backend receives project metadata, but this service intentionally does
/// not upload room photos. Reinstalling the app or opening the project on a
/// second phone therefore may show project metadata without the private photo.
class ProjectLocalStore {
  Future<Directory> _projectDir(String projectId) async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory('${root.path}/ata_projects/$projectId');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> save({
    required String projectId,
    String? sourceImagePath,
    WallMask? wallMask,
    WallPolygon? wallPolygon,
  }) async {
    final dir = await _projectDir(projectId);
    String? imageName;
    if (sourceImagePath != null && await File(sourceImagePath).exists()) {
      final ext = _extension(sourceImagePath);
      imageName = 'room$ext';
      await File(sourceImagePath).copy('${dir.path}/$imageName');
    }

    final payload = <String, Object?>{
      if (imageName != null) 'image_name': imageName,
      if (wallMask != null)
        'wall_mask': <String, Object?>{
          'width': wallMask.width,
          'height': wallMask.height,
          'data_b64': base64Encode(wallMask.data),
        },
      if (wallPolygon != null)
        'wall_polygon': wallPolygon.points
            .map((p) => <String, double>{'x': p.dx, 'y': p.dy})
            .toList(growable: false),
    };
    await File('${dir.path}/project_local.json').writeAsString(jsonEncode(payload), flush: true);
  }

  Future<LocalProjectData> read(String projectId) async {
    final dir = await _projectDir(projectId);
    final jsonFile = File('${dir.path}/project_local.json');
    if (!await jsonFile.exists()) return const LocalProjectData();
    try {
      final raw = jsonDecode(await jsonFile.readAsString()) as Map<String, dynamic>;
      final imageName = raw['image_name'] as String?;
      final imagePath = imageName == null ? null : '${dir.path}/$imageName';

      WallMask? mask;
      final maskJson = raw['wall_mask'];
      if (maskJson is Map<String, dynamic>) {
        final bytes = base64Decode(maskJson['data_b64'] as String);
        mask = WallMask(
          width: maskJson['width'] as int,
          height: maskJson['height'] as int,
          data: Uint8List.fromList(bytes),
        );
      }

      WallPolygon? polygon;
      final polygonJson = raw['wall_polygon'];
      if (polygonJson is List) {
        final points = polygonJson
            .whereType<Map<String, dynamic>>()
            .map((e) => Offset((e['x'] as num).toDouble(), (e['y'] as num).toDouble()))
            .toList(growable: false);
        if (points.length >= 3) polygon = WallPolygon(points);
      }
      return LocalProjectData(imagePath: imagePath, wallMask: mask, wallPolygon: polygon);
    } catch (_) {
      return const LocalProjectData();
    }
  }

  Future<void> delete(String projectId) async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory('${root.path}/ata_projects/$projectId');
    if (await dir.exists()) await dir.delete(recursive: true);
  }

  static String _extension(String path) {
    final name = path.split('/').last;
    final dot = name.lastIndexOf('.');
    if (dot < 0 || dot == name.length - 1) return '.jpg';
    final ext = name.substring(dot).toLowerCase();
    if (ext.length > 6) return '.jpg';
    return ext;
  }
}
