import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Sound + haptic feedback for ATA's rotary color pickers.
///
/// The wheel deliberately emits feedback only when crossing an item boundary,
/// not for every pointer pixel. This keeps rapid spins crisp rather than noisy.
class RotaryFeedbackService extends ChangeNotifier {
  RotaryFeedbackService._();

  static final RotaryFeedbackService instance = RotaryFeedbackService._();

  static const _soundKey = 'ata_rotary_sound_enabled';
  static const _hapticsKey = 'ata_rotary_haptics_enabled';

  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();

  AudioPool? _tickPool;
  AudioPool? _lockPool;
  bool _initialized = false;
  bool _initializing = false;
  bool _soundEnabled = true;
  bool _hapticsEnabled = true;
  DateTime _lastTickAt = DateTime.fromMillisecondsSinceEpoch(0);

  bool get soundEnabled => _soundEnabled;
  bool get hapticsEnabled => _hapticsEnabled;

  Future<void> init() async {
    if (_initialized || _initializing) return;
    _initializing = true;
    try {
      _soundEnabled = await _prefs.getBool(_soundKey) ?? true;
      _hapticsEnabled = await _prefs.getBool(_hapticsKey) ?? true;

      // AudioPool preloads the tiny assets and is suitable for rapid repeated UI sounds.
      _tickPool = await AudioPool.createFromAsset(
        path: 'audio/rotary_tick.wav',
        minPlayers: 2,
        maxPlayers: 5,
        playerMode: PlayerMode.lowLatency,
      );
      _lockPool = await AudioPool.createFromAsset(
        path: 'audio/rotary_lock.wav',
        minPlayers: 1,
        maxPlayers: 2,
        playerMode: PlayerMode.lowLatency,
      );
      _initialized = true;
      notifyListeners();
    } finally {
      _initializing = false;
    }
  }

  Future<void> setSoundEnabled(bool value) async {
    _soundEnabled = value;
    notifyListeners();
    await _prefs.setBool(_soundKey, value);
  }

  Future<void> setHapticsEnabled(bool value) async {
    _hapticsEnabled = value;
    notifyListeners();
    await _prefs.setBool(_hapticsKey, value);
  }

  Future<void> tick() async {
    await init();
    final now = DateTime.now();
    // Avoid a machine-gun effect during a very fast fling.
    if (now.difference(_lastTickAt).inMilliseconds < 34) return;
    _lastTickAt = now;

    if (_hapticsEnabled) {
      unawaited(HapticFeedback.selectionClick());
    }
    if (_soundEnabled) {
      final pool = _tickPool;
      if (pool != null) unawaited(_startPool(pool, .22));
    }
  }

  Future<void> _startPool(AudioPool pool, double volume) async {
    await pool.start(volume: volume);
  }

  Future<void> settle() async {
    await init();
    if (_hapticsEnabled) {
      unawaited(HapticFeedback.lightImpact());
    }
    if (_soundEnabled) {
      final pool = _lockPool;
      if (pool != null) unawaited(_startPool(pool, .30));
    }
  }
}
