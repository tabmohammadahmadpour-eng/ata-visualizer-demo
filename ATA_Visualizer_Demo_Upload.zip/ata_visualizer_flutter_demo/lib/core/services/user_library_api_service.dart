import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/api_config.dart';
import '../config/app_config.dart';
import '../models/color_family.dart';
import '../models/saved_project.dart';
import 'secure_session_store.dart';

class UserLibraryException implements Exception {
  final String message;
  const UserLibraryException(this.message);
  @override
  String toString() => message;
}

class UserLibraryApiService {
  final http.Client _client;
  final SecureSessionStore _sessionStore;
  final String baseUrl;

  static const _projectsKey = 'ata_demo_projects_v1';
  static const _favoritesKey = 'ata_demo_favorites_v1';

  UserLibraryApiService({http.Client? client, SecureSessionStore? sessionStore, String? baseUrl})
      : _client = client ?? http.Client(),
        _sessionStore = sessionStore ?? const SecureSessionStore(),
        baseUrl = baseUrl ?? ApiConfig.baseUrl;

  Future<List<SavedProject>> listProjects() async {
    if (AppConfig.demoMode) {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList(_projectsKey) ?? const <String>[];
      final items = raw
          .map((e) => SavedProject.fromJson(jsonDecode(e) as Map<String, dynamic>))
          .toList();
      items.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return items;
    }
    final json = await _request('GET', '/projects');
    return (json['items'] as List<dynamic>? ?? const [])
        .map((e) => SavedProject.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<SavedProject> createProject({
    required String title,
    required AtaPaintColor color,
    String? familyName,
    required bool hasImage,
    required bool hasAiMask,
  }) async {
    if (AppConfig.demoMode) {
      final now = DateTime.now();
      final project = SavedProject(
        id: 'demo-project-${now.microsecondsSinceEpoch}',
        title: title,
        ataCode: color.code,
        nameFa: color.nameFa,
        familyId: color.familyId,
        familyName: familyName,
        rgb: color.rgb,
        hex: color.hex,
        hasImage: hasImage,
        hasAiMask: hasAiMask,
        createdAt: now,
        updatedAt: now,
      );
      final items = await listProjects();
      items.insert(0, project);
      await _saveProjects(items);
      return project;
    }

    final json = await _request('POST', '/projects', body: <String, Object?>{
      'title': title,
      'ata_code': color.code,
      'name_fa': color.nameFa,
      'family_id': color.familyId,
      if (familyName != null) 'family_name': familyName,
      'rgb': color.rgb,
      'hex': color.hex,
      'has_image': hasImage,
      'has_ai_mask': hasAiMask,
    });
    return SavedProject.fromJson(json);
  }

  Future<SavedProject> renameProject(String id, String title) async {
    if (AppConfig.demoMode) {
      final items = await listProjects();
      final index = items.indexWhere((e) => e.id == id);
      if (index < 0) throw const UserLibraryException('پروژه پیدا نشد.');
      final old = items[index];
      final updated = SavedProject(
        id: old.id,
        title: title,
        ataCode: old.ataCode,
        nameFa: old.nameFa,
        familyId: old.familyId,
        familyName: old.familyName,
        rgb: old.rgb,
        hex: old.hex,
        hasImage: old.hasImage,
        hasAiMask: old.hasAiMask,
        createdAt: old.createdAt,
        updatedAt: DateTime.now(),
      );
      items[index] = updated;
      await _saveProjects(items);
      return updated;
    }
    final json = await _request('PATCH', '/projects/$id', body: {'title': title});
    return SavedProject.fromJson(json);
  }

  Future<void> deleteProject(String id) async {
    if (AppConfig.demoMode) {
      final items = await listProjects();
      items.removeWhere((e) => e.id == id);
      await _saveProjects(items);
      return;
    }
    await _request('DELETE', '/projects/$id', expectNoContent: true);
  }

  Future<List<FavoriteColorRecord>> listFavorites() async {
    if (AppConfig.demoMode) {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList(_favoritesKey) ?? const <String>[];
      final items = raw
          .map((e) => FavoriteColorRecord.fromJson(jsonDecode(e) as Map<String, dynamic>))
          .toList();
      items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return items;
    }
    final json = await _request('GET', '/favorites');
    return (json['items'] as List<dynamic>? ?? const [])
        .map((e) => FavoriteColorRecord.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<FavoriteColorRecord> saveFavorite(AtaPaintColor color, {String? familyName}) async {
    if (AppConfig.demoMode) {
      final items = await listFavorites();
      final existing = items.where((e) => e.ataCode == color.code).toList();
      if (existing.isNotEmpty) return existing.first;
      final item = FavoriteColorRecord(
        id: 'demo-favorite-${DateTime.now().microsecondsSinceEpoch}',
        ataCode: color.code,
        nameFa: color.nameFa,
        familyId: color.familyId,
        familyName: familyName,
        rgb: color.rgb,
        hex: color.hex,
        createdAt: DateTime.now(),
      );
      items.insert(0, item);
      await _saveFavorites(items);
      return item;
    }

    final json = await _request('POST', '/favorites', body: <String, Object?>{
      'ata_code': color.code,
      'name_fa': color.nameFa,
      'family_id': color.familyId,
      if (familyName != null) 'family_name': familyName,
      'rgb': color.rgb,
      'hex': color.hex,
    });
    return FavoriteColorRecord.fromJson(json);
  }

  Future<void> deleteFavorite(String ataCode) async {
    if (AppConfig.demoMode) {
      final items = await listFavorites();
      items.removeWhere((e) => e.ataCode == ataCode);
      await _saveFavorites(items);
      return;
    }
    await _request('DELETE', '/favorites/${Uri.encodeComponent(ataCode)}', expectNoContent: true);
  }

  Future<void> _saveProjects(List<SavedProject> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _projectsKey,
      items.map((e) => jsonEncode(<String, Object?>{
        'id': e.id,
        'title': e.title,
        'ata_code': e.ataCode,
        'name_fa': e.nameFa,
        'family_id': e.familyId,
        'family_name': e.familyName,
        'rgb': e.rgb,
        'hex': e.hex,
        'has_image': e.hasImage,
        'has_ai_mask': e.hasAiMask,
        'created_at': e.createdAt.toIso8601String(),
        'updated_at': e.updatedAt.toIso8601String(),
      })).toList(growable: false),
    );
  }

  Future<void> _saveFavorites(List<FavoriteColorRecord> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _favoritesKey,
      items.map((e) => jsonEncode(<String, Object?>{
        'id': e.id,
        'ata_code': e.ataCode,
        'name_fa': e.nameFa,
        'family_id': e.familyId,
        'family_name': e.familyName,
        'rgb': e.rgb,
        'hex': e.hex,
        'created_at': e.createdAt.toIso8601String(),
      })).toList(growable: false),
    );
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, Object?>? body,
    bool expectNoContent = false,
  }) async {
    final token = await _sessionStore.readToken();
    if (token == null || token.isEmpty) throw const UserLibraryException('برای این عملیات باید وارد حساب شوید.');

    final uri = Uri.parse('$baseUrl$path');
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      late http.Response response;
      switch (method) {
        case 'GET':
          response = await _client.get(uri, headers: headers);
          break;
        case 'POST':
          response = await _client.post(uri, headers: headers, body: body == null ? null : jsonEncode(body));
          break;
        case 'PATCH':
          response = await _client.patch(uri, headers: headers, body: body == null ? null : jsonEncode(body));
          break;
        case 'DELETE':
          response = await _client.delete(uri, headers: headers);
          break;
        default:
          throw StateError('Unsupported method $method');
      }
      if (expectNoContent && response.statusCode >= 200 && response.statusCode < 300) return const {};
      final decoded = response.bodyBytes.isEmpty
          ? <String, dynamic>{}
          : jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw UserLibraryException(decoded['detail'] as String? ?? 'عملیات انجام نشد.');
      }
      return decoded;
    } on UserLibraryException {
      rethrow;
    } catch (_) {
      throw const UserLibraryException('ارتباط با سرور برقرار نشد.');
    }
  }
}
