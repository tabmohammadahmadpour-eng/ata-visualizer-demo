import '../models/wall_detection_result.dart';

/// Contract for automatic wall detection.
///
/// Version 0.5 ships with a lightweight local smart detector so the button is
/// already functional offline. A semantic-segmentation AI model can replace it
/// later through this same interface.
abstract interface class WallDetectionService {
  Future<WallDetectionResult?> detectWall(String imagePath);
}
