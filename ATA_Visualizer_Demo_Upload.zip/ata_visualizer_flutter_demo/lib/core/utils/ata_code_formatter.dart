class AtaCodeFormatter {
  const AtaCodeFormatter._();

  /// Converts catalog codes such as:
  /// NP BGG 1596A -> ATA 1596 A
  /// NP OW 1027P  -> ATA 1027 P
  /// 144          -> ATA 144
  static String fromSource(String sourceCode) {
    final compact = sourceCode.trim().toUpperCase();
    final match = RegExp(r'(\d{2,5})\s*([A-Z]?)\s*$').firstMatch(compact);
    if (match == null) {
      throw FormatException('کد رنگ قابل تبدیل نیست: $sourceCode');
    }

    final number = match.group(1)!;
    final suffix = match.group(2) ?? '';
    return suffix.isEmpty ? 'ATA $number' : 'ATA $number $suffix';
  }

  static int numericPart(String sourceCode) {
    final match = RegExp(r'(\d{2,5})\s*[A-Z]?\s*$')
        .firstMatch(sourceCode.trim().toUpperCase());
    if (match == null) throw FormatException('کد نامعتبر: $sourceCode');
    return int.parse(match.group(1)!);
  }

  static String suffix(String sourceCode) {
    final match = RegExp(r'(\d{2,5})\s*([A-Z]?)\s*$')
        .firstMatch(sourceCode.trim().toUpperCase());
    if (match == null) throw FormatException('کد نامعتبر: $sourceCode');
    return match.group(2) ?? '';
  }
}
