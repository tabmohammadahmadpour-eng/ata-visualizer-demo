import 'package:flutter/material.dart';

class AtaColors {
  static const blue = Color(0xFF0057D9);
  static const red = Color(0xFFE0131A);
  static const yellow = Color(0xFFFFC107);
  static const black = Color(0xFF111111);
  static const softGray = Color(0xFFF2F2F2);
  static const border = Color(0xFFE5E7EB);
  static const muted = Color(0xFF6B7280);
}

class AtaTheme {
  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: AtaColors.blue,
      brightness: Brightness.light,
      primary: AtaColors.blue,
      secondary: AtaColors.red,
      surface: Colors.white,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: Colors.white,
      fontFamily: null,
      appBarTheme: const AppBarTheme(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: AtaColors.black,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: AtaColors.border),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AtaColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AtaColors.border),
        ),
      ),
    );
  }
}
