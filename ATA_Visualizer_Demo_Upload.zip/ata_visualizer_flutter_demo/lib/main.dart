import 'package:flutter/material.dart';

import 'core/config/app_config.dart';
import 'core/theme/ata_theme.dart';
import 'features/auth/auth_gate.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AtaVisualizerApp());
}

class AtaVisualizerApp extends StatelessWidget {
  const AtaVisualizerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConfig.demoMode ? 'ATA Visualizer Demo' : 'ATA Visualizer',
      theme: AtaTheme.light,
      home: const AuthGate(),
    );
  }
}
