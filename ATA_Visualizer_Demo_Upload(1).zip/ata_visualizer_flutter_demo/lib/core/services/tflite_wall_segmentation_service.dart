import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:tflite_flutter/tflite_flutter.dart';

import '../models/segmentation_model_manifest.dart';
import '../models/wall_detection_result.dart';
import '../models/wall_mask.dart';
import 'model_manifest_service.dart';
import 'wall_detection_service.dart';
import 'wall_mask_postprocessor.dart';

/// Production-oriented on-device segmentation adapter.
///
/// v0.7 no longer hard-codes the model contract in Dart. The contract lives in
/// assets/models/model_manifest.json so a future model can be replaced without
/// rewriting the UI layer. Two output contracts are supported:
/// - binary_probability: [1,H,W,1] float probability mask.
/// - class_map: [1,H,W] or [1,H,W,1] integer class indices.
class TfliteWallSegmentationService implements WallDetectionService {
  final ModelManifestService manifestService;
  final WallDetectionService? fallback;
  final WallMaskPostprocessor postprocessor;

  Interpreter? _interpreter;
  SegmentationModelManifest? _manifest;
  bool _modelUnavailable = false;

  TfliteWallSegmentationService({
    this.manifestService = const ModelManifestService(),
    this.fallback,
    this.postprocessor = const WallMaskPostprocessor(),
  });

  @override
  Future<WallDetectionResult?> detectWall(String imagePath) async {
    try {
      final manifest = await _loadManifest();
      final interpreter = await _loadInterpreter(manifest);
      if (interpreter == null) return fallback?.detectWall(imagePath);

      final inputTensor = interpreter.getInputTensor(0);
      final outputTensor = interpreter.getOutputTensor(0);
      _validateInput(inputTensor, manifest);

      final inH = inputTensor.shape[1];
      final inW = inputTensor.shape[2];
      final imageBytes = await _decodeRgb(imagePath, inW, inH);
      final input = _buildInput(imageBytes, inputTensor.type, inW, inH, manifest);

      final mask = switch (manifest.outputKind) {
        'binary_probability' => _runBinaryProbability(
            interpreter,
            input,
            outputTensor,
            manifest,
          ),
        'class_map' => _runClassMap(
            interpreter,
            input,
            outputTensor,
            manifest,
          ),
        _ => throw UnsupportedError(
            'نوع خروجی مدل پشتیبانی نمی‌شود: ${manifest.outputKind}',
          ),
      };

      if (!mask.isValid ||
          mask.coverage < manifest.minWallCoverage ||
          mask.coverage > manifest.maxWallCoverage) {
        return fallback?.detectWall(imagePath);
      }

      return WallDetectionResult(
        mask: mask,
        confidence: null,
        method: WallDetectionMethod.aiModel,
        modelLabel: manifest.modelId,
      );
    } catch (_) {
      return fallback?.detectWall(imagePath);
    }
  }

  Future<SegmentationModelManifest> _loadManifest() async {
    return _manifest ??= await manifestService.load();
  }

  Future<Interpreter?> _loadInterpreter(SegmentationModelManifest manifest) async {
    if (_modelUnavailable) return null;
    if (_interpreter != null) return _interpreter;
    try {
      final options = InterpreterOptions()..threads = 4;
      _interpreter = await Interpreter.fromAsset(manifest.assetPath, options: options);
      return _interpreter;
    } catch (_) {
      _modelUnavailable = true;
      return null;
    }
  }

  void _validateInput(Tensor input, SegmentationModelManifest manifest) {
    final shape = input.shape;
    if (shape.length != 4 || shape.first != 1 || shape.last != 3) {
      throw UnsupportedError('مدل باید ورودی [1,H,W,3] داشته باشد.');
    }
    if (manifest.inputChannels != 3) {
      throw UnsupportedError('نسخه فعلی ATA فقط ورودی RGB سه‌کاناله را پشتیبانی می‌کند.');
    }
  }

  WallMask _runBinaryProbability(
    Interpreter interpreter,
    Object input,
    Tensor outputTensor,
    SegmentationModelManifest manifest,
  ) {
    final shape = outputTensor.shape;
    if (shape.length != 4 || shape.first != 1 || shape.last != 1) {
      throw UnsupportedError('خروجی binary_probability باید [1,H,W,1] باشد.');
    }
    final h = shape[1];
    final w = shape[2];
    final output = List.generate(
      1,
      (_) => List.generate(
        h,
        (_) => List.generate(w, (_) => <double>[0]),
      ),
    );
    interpreter.run(input, output);

    final probs = List<double>.filled(w * h, 0);
    for (int y = 0; y < h; y++) {
      for (int x = 0; x < w; x++) {
        probs[y * w + x] = (output[0][y][x][0] as num).toDouble();
      }
    }
    return postprocessor.fromBinaryProbabilities(
      probabilities: probs,
      width: w,
      height: h,
      threshold: manifest.threshold,
      keepLargestComponent: manifest.keepLargestComponent,
    );
  }

  WallMask _runClassMap(
    Interpreter interpreter,
    Object input,
    Tensor outputTensor,
    SegmentationModelManifest manifest,
  ) {
    final shape = outputTensor.shape;
    if (shape.length != 3 && shape.length != 4) {
      throw UnsupportedError('خروجی class_map باید [1,H,W] یا [1,H,W,1] باشد.');
    }
    if (shape.first != 1 || (shape.length == 4 && shape.last != 1)) {
      throw UnsupportedError('خروجی class_map با قرارداد ATA سازگار نیست.');
    }
    final h = shape[1];
    final w = shape[2];
    final dynamic output = shape.length == 3
        ? List.generate(1, (_) => List.generate(h, (_) => List<num>.filled(w, 0)))
        : List.generate(
            1,
            (_) => List.generate(
              h,
              (_) => List.generate(w, (_) => <num>[0]),
            ),
          );
    interpreter.run(input, output);

    final classes = List<int>.filled(w * h, 0);
    for (int y = 0; y < h; y++) {
      for (int x = 0; x < w; x++) {
        final num raw = shape.length == 3
            ? output[0][y][x] as num
            : output[0][y][x][0] as num;
        classes[y * w + x] = raw.round();
      }
    }
    return postprocessor.fromClassMap(
      classes: classes,
      width: w,
      height: h,
      wallClassIndex: manifest.wallClassIndex,
      keepLargestComponent: manifest.keepLargestComponent,
    );
  }

  Future<Uint8List> _decodeRgb(String path, int width, int height) async {
    final bytes = await File(path).readAsBytes();
    final codec = await ui.instantiateImageCodec(
      bytes,
      targetWidth: width,
      targetHeight: height,
      allowUpscaling: true,
    );
    final frame = await codec.getNextFrame();
    final image = frame.image;
    final rgbaData = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (rgbaData == null) {
      image.dispose();
      codec.dispose();
      throw StateError('خواندن تصویر برای مدل انجام نشد.');
    }
    final rgba = rgbaData.buffer.asUint8List();
    final rgb = Uint8List(width * height * 3);
    int o = 0;
    for (int i = 0; i < width * height; i++) {
      final p = i * 4;
      rgb[o++] = rgba[p];
      rgb[o++] = rgba[p + 1];
      rgb[o++] = rgba[p + 2];
    }
    image.dispose();
    codec.dispose();
    return rgb;
  }

  Object _buildInput(
    Uint8List rgb,
    TensorType type,
    int width,
    int height,
    SegmentationModelManifest manifest,
  ) {
    final shape = [1, height, width, 3];
    switch (type) {
      case TensorType.float32:
        final values = Float32List(rgb.length);
        for (int i = 0; i < rgb.length; i++) {
          values[i] = switch (manifest.normalization) {
            'zero_to_one' => rgb[i] / 255.0,
            'minus_one_to_one' => (rgb[i] - 127.5) / 127.5,
            _ => rgb[i].toDouble(),
          };
        }
        return values.reshape(shape);
      case TensorType.uint8:
        return rgb.reshape(shape);
      case TensorType.int8:
        final values = Int8List(rgb.length);
        for (int i = 0; i < rgb.length; i++) {
          values[i] = rgb[i] - 128;
        }
        return values.reshape(shape);
      default:
        throw UnsupportedError('نوع ورودی مدل پشتیبانی نمی‌شود: $type');
    }
  }

  void dispose() {
    _interpreter?.close();
    _interpreter = null;
  }
}
